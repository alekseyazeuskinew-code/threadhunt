// src/popup.ts
var $ = (id) => document.getElementById(id);
async function refresh() {
  const { api, token } = await chrome.storage.local.get(["api", "token"]);
  $("api").value = api || "https://threadhuntserver-production.up.railway.app";
  $("token").value = token || "";
  const connected = !!token;
  $("dot").classList.toggle("on", connected);
  $("status").textContent = connected ? "\u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E" : "\u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E";
  void showResult();
}
$("save").addEventListener("click", async () => {
  const api = $("api").value.trim().replace(/\/$/, "");
  const token = $("token").value.trim();
  await chrome.storage.local.set({ api, token });
  $("status").textContent = "\u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E";
  refresh();
});
var REASONS = {
  not_messages: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0432\u043A\u043B\u0430\u0434\u043A\u0443 Threads \u2192 \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0441\u043D\u043E\u0432\u0430.",
  no_keywords: "\u041D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u043A\u043E\u0434\u043E\u0432\u044B\u0445 \u0441\u043B\u043E\u0432 \u2014 \u0434\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0438\u0445 \u0432 \u043F\u043E\u0438\u0441\u043A \u0432 \u043A\u0430\u0431\u0438\u043D\u0435\u0442\u0435.",
  busy: "\u0421\u0435\u0439\u0447\u0430\u0441 \u0443\u0436\u0435 \u0438\u0434\u0451\u0442 \u043F\u0440\u043E\u0445\u043E\u0434. \u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430.",
  no_receiver: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0432\u043A\u043B\u0430\u0434\u043A\u0443 Threads \u2192 \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u0441\u043D\u043E\u0432\u0430."
};
function setRes(html) {
  const el = $("testres");
  el.style.display = "block";
  el.innerHTML = html;
}
async function showResult() {
  const { th_test_result: r } = await chrome.storage.local.get("th_test_result");
  if (!r) return;
  if (r.done) {
    setRes(`\u0413\u043E\u0442\u043E\u0432\u043E: \u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043E <b class="accent">${r.scanned}</b> \u0434\u0438\u0430\u043B\u043E\u0433\u043E\u0432, \u043E\u0442\u0432\u0435\u0442\u0438\u043B \u0431\u044B \u043D\u0430 <b class="accent">${r.matched}</b>.<br/><span class="muted">\u041E\u0442\u043F\u0440\u0430\u0432\u043E\u043A: 0 \u2014 \u044D\u0442\u043E \u0442\u0435\u0441\u0442.</span>`);
  } else {
    setRes(`\u0418\u0434\u0451\u0442 \u0442\u0435\u0441\u0442\u2026 \u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043E ${r.scanned}, \u0441\u043E\u0432\u043F\u0430\u0434\u0435\u043D\u0438\u0439 ${r.matched}`);
  }
  return r;
}
$("test").addEventListener("click", async () => {
  const btn = $("test");
  btn.disabled = true;
  setRes("\u0417\u0430\u043F\u0443\u0441\u043A\u0430\u044E \u0442\u0435\u0441\u0442\u2026");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setRes(REASONS.not_messages);
    btn.disabled = false;
    return;
  }
  chrome.tabs.sendMessage(tab.id, { type: "startTest" }, (resp) => {
    if (chrome.runtime.lastError || !resp) {
      setRes(REASONS.no_receiver);
      btn.disabled = false;
      return;
    }
    if (!resp.ok) {
      setRes(REASONS[resp.reason] || "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0442\u0435\u0441\u0442.");
      btn.disabled = false;
      return;
    }
    const started = Date.now();
    const poll = setInterval(async () => {
      const r = await showResult();
      if (r && r.done || Date.now() - started > 12e4) {
        clearInterval(poll);
        btn.disabled = false;
      }
    }, 3e3);
  });
});
refresh();
