// src/background.ts
var DEFAULT_API = "https://threadhuntserver-production.up.railway.app";
var VERSION = "0.1.12";
chrome.storage.session.setAccessLevel?.({ accessLevel: "TRUSTED_AND_UNTRUSTED_CONTEXTS" });
async function cfg() {
  const { api, token } = await chrome.storage.local.get(["api", "token"]);
  let resolved = api || DEFAULT_API;
  if (/localhost|127\.0\.0\.1/.test(resolved)) {
    resolved = DEFAULT_API;
    void chrome.storage.local.set({ api: resolved });
  }
  return { api: resolved, token: token || null };
}
async function authed(path, init = {}) {
  const { api, token } = await cfg();
  if (!token) return null;
  return fetch(api + path, {
    ...init,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...init.headers || {} }
  });
}
chrome.alarms.create("tick", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "tick") void tick();
});
async function tick() {
  const { threadsLoggedIn } = await chrome.storage.local.get("threadsLoggedIn");
  void authed("/api/agent/heartbeat", { method: "POST", body: JSON.stringify({ version: VERSION, threadsLoggedIn: !!threadsLoggedIn }) });
  const res = await authed("/api/agent/tasks");
  if (!res || !res.ok) return;
  const tasks = await res.json();
  await chrome.storage.local.set({ tasks });
  await maybeRunTestInBackground(tasks);
  await maybeRunResearchInBackground(tasks);
}
async function maybeRunResearchInBackground(tasks) {
  const { researchHandledAt, researchTabOpenedAt, researchTabId } = await chrome.storage.local.get(["researchHandledAt", "researchTabOpenedAt", "researchTabId"]);
  if (researchTabId != null && researchTabOpenedAt && Date.now() - researchTabOpenedAt > 5 * 6e4) await closeResearchTab();
  const r = tasks.research;
  const runAt = r?.runAt;
  if (!runAt) return;
  if (researchHandledAt === runAt) return;
  if (!r?.enabled || !r.queries?.length) {
    await chrome.storage.local.set({ researchHandledAt: runAt });
    void authed("/api/agent/research", { method: "POST", body: JSON.stringify({ posts: [] }) }).then(() => void tick());
    return;
  }
  await closeResearchTab();
  try {
    const queue = r.queries.slice(0, 12);
    await chrome.storage.session.set({ research: { queue, idx: 0, maxPerQuery: r.maxPerQuery || 15, collected: 0 }, lastResearchRunNow: Date.parse(runAt) });
    const url = "https://www.threads.com/search?q=" + encodeURIComponent(queue[0].query) + "&serp_type=default";
    const tab = await chrome.tabs.create({ url, active: true });
    await chrome.storage.local.set({ researchHandledAt: runAt, researchTabId: tab.id ?? null, researchTabOpenedAt: Date.now() });
  } catch {
  }
}
async function closeResearchTab() {
  const { researchTabId } = await chrome.storage.local.get("researchTabId");
  if (researchTabId != null) {
    try {
      await chrome.tabs.remove(researchTabId);
    } catch {
    }
    await chrome.storage.local.remove(["researchTabId", "researchTabOpenedAt"]);
  }
}
async function maybeRunTestInBackground(tasks) {
  const dmTestAt = tasks.dmTestAt;
  if (!dmTestAt) {
    await closeTestTab();
    return;
  }
  const { testHandledAt, testTabOpenedAt } = await chrome.storage.local.get(["testHandledAt", "testTabOpenedAt"]);
  if (testHandledAt === dmTestAt) {
    if (testTabOpenedAt && Date.now() - testTabOpenedAt > 4 * 6e4) await closeTestTab();
    return;
  }
  await closeTestTab();
  try {
    const tab = await chrome.tabs.create({ url: "https://www.threads.com/messages/", active: false });
    await chrome.storage.local.set({ testHandledAt: dmTestAt, testTabId: tab.id ?? null, testTabOpenedAt: Date.now() });
  } catch {
  }
}
async function closeTestTab() {
  const { testTabId } = await chrome.storage.local.get("testTabId");
  if (testTabId != null) {
    try {
      await chrome.tabs.remove(testTabId);
    } catch {
    }
    await chrome.storage.local.remove(["testTabId", "testTabOpenedAt"]);
  }
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "heartbeat") {
    void chrome.storage.local.set({ threadsLoggedIn: !!msg.threadsLoggedIn });
    void authed("/api/agent/heartbeat", {
      method: "POST",
      body: JSON.stringify({ version: VERSION, threadsLoggedIn: !!msg.threadsLoggedIn })
    });
  }
  if (msg?.type === "events") {
    const events = msg.events;
    void authed("/api/agent/events", { method: "POST", body: JSON.stringify({ events }) }).then(() => {
      void tick();
    });
  }
  if (msg?.type === "pass") {
    void authed("/api/agent/pass", { method: "POST", body: JSON.stringify(msg.report || {}) }).then(() => {
      void tick();
    });
  }
  if (msg?.type === "research") {
    void authed("/api/agent/research", { method: "POST", body: JSON.stringify({ posts: msg.posts || [], diag: msg.diag || null }) });
  }
  if (msg?.type === "researchDone") {
    void authed("/api/agent/research", { method: "POST", body: JSON.stringify({ posts: [] }) }).then(() => void tick());
    void closeResearchTab();
  }
  if (msg?.type === "testResult") {
    void authed("/api/agent/test-result", { method: "POST", body: JSON.stringify({ scanned: msg.scanned || 0, matched: msg.matched || 0 }) }).then(() => void tick());
    void closeTestTab();
  }
  if (msg?.type === "getTasks") {
    chrome.storage.local.get("tasks").then((s) => sendResponse(s.tasks || null));
    return true;
  }
});
void tick();
