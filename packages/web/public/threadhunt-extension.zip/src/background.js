// src/background.ts
var DEFAULT_API = "https://threadhuntserver-production.up.railway.app";
var VERSION = "0.1.2";
chrome.storage.session.setAccessLevel?.({ accessLevel: "TRUSTED_AND_UNTRUSTED_CONTEXTS" });
async function cfg() {
  const { api, token } = await chrome.storage.local.get(["api", "token"]);
  return { api: api || DEFAULT_API, token: token || null };
}
async function authed(path, init = {}) {
  const { api, token } = await cfg();
  if (!token) return null;
  return fetch(api + path, {
    ...init,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...init.headers || {} }
  });
}
chrome.alarms.create("tick", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "tick") void tick();
});
async function tick() {
  const res = await authed("/api/agent/tasks");
  if (!res || !res.ok) return;
  const tasks = await res.json();
  await chrome.storage.local.set({ tasks });
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "heartbeat") {
    void authed("/api/agent/heartbeat", {
      method: "POST",
      body: JSON.stringify({ version: VERSION, threadsLoggedIn: !!msg.threadsLoggedIn })
    });
  }
  if (msg?.type === "events") {
    const events = msg.events;
    void authed("/api/agent/events", { method: "POST", body: JSON.stringify({ events }) }).then(() => {
      void tick();
    });
  }
  if (msg?.type === "pass") {
    void authed("/api/agent/pass", { method: "POST", body: JSON.stringify(msg.report || {}) }).then(() => {
      void tick();
    });
  }
  if (msg?.type === "research") {
    void authed("/api/agent/research", { method: "POST", body: JSON.stringify({ posts: msg.posts || [] }) });
  }
  if (msg?.type === "getTasks") {
    chrome.storage.local.get("tasks").then((s) => sendResponse(s.tasks || null));
    return true;
  }
});
void tick();
