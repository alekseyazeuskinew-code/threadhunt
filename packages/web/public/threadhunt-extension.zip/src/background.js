// src/background.ts
var DEFAULT_API = "https://threadhuntserver-production.up.railway.app";
var VERSION = chrome.runtime.getManifest().version;
async function openWorkWindow(url) {
  const win = await chrome.windows.create({ url, focused: false, state: "minimized" });
  const tab = win.tabs?.[0];
  return { windowId: win.id ?? null, tabId: tab?.id ?? null };
}
async function closeWorkWindow(windowId, tabId) {
  if (windowId != null) {
    try {
      await chrome.windows.remove(windowId);
      return;
    } catch {
    }
  }
  if (tabId != null) {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
    }
  }
}
chrome.storage.session.setAccessLevel?.({ accessLevel: "TRUSTED_AND_UNTRUSTED_CONTEXTS" });
async function cfg() {
  const { api, token } = await chrome.storage.local.get(["api", "token"]);
  let resolved = api || DEFAULT_API;
  if (/localhost|127\.0\.0\.1/.test(resolved)) {
    resolved = DEFAULT_API;
    void chrome.storage.local.set({ api: resolved });
  }
  return { api: resolved, token: token || null };
}
async function authed(path, init = {}) {
  const { api, token } = await cfg();
  if (!token) return null;
  return fetch(api + path, {
    ...init,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...init.headers || {} }
  });
}
chrome.alarms.create("tick", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "tick") void tick();
});
async function tick() {
  const { threadsLoggedIn } = await chrome.storage.local.get("threadsLoggedIn");
  void authed("/api/agent/heartbeat", { method: "POST", body: JSON.stringify({ version: VERSION, threadsLoggedIn: !!threadsLoggedIn }) });
  const res = await authed("/api/agent/tasks");
  if (!res || !res.ok) return;
  const tasks = await res.json();
  await chrome.storage.local.set({ tasks });
  await maybeRunTestInBackground(tasks);
  await maybeRunResearchInBackground(tasks);
  await maybeRunSweepInBackground(tasks);
  await maybeRunScheduledSweep(tasks);
}
function withinWorkingHours(wh) {
  if (!wh || !wh.enabled) return true;
  const d = /* @__PURE__ */ new Date();
  const cur = d.getHours() * 60 + d.getMinutes();
  const [fh, fm] = wh.from.split(":").map(Number);
  const [th, tm] = wh.to.split(":").map(Number);
  const from = fh * 60 + fm;
  const to = th * 60 + tm;
  return from <= to ? cur >= from && cur <= to : cur >= from || cur <= to;
}
async function maybeRunScheduledSweep(tasks) {
  const { scheduledSweepTabId, scheduledSweepOpenedAt } = await chrome.storage.local.get(["scheduledSweepTabId", "scheduledSweepOpenedAt"]);
  if (scheduledSweepTabId != null) {
    if (scheduledSweepOpenedAt && Date.now() - scheduledSweepOpenedAt > 4 * 6e4) await closeScheduledSweepTab();
    return;
  }
  const { sweepTabId, testTabId, researchTabId } = await chrome.storage.local.get(["sweepTabId", "testTabId", "researchTabId"]);
  if (sweepTabId != null || testTabId != null || researchTabId != null) return;
  const lim = tasks.limits;
  if (!tasks.active || !tasks.searches?.length) return;
  if (lim?.runNowAt) return;
  if (!withinWorkingHours(lim?.workingHours)) return;
  if (lim && (lim.repliesRemainingToday ?? 0) <= 0 && !lim.safeMode) return;
  const cooldownMs = Math.max(30, lim?.sweepIntervalMinutes ?? 180) * 6e4;
  const { lastSweepAt } = await chrome.storage.session.get("lastSweepAt");
  if (lastSweepAt && Date.now() - lastSweepAt < cooldownMs) return;
  try {
    const { windowId, tabId } = await openWorkWindow("https://www.threads.com/messages/");
    await chrome.storage.local.set({ scheduledSweepWindowId: windowId, scheduledSweepTabId: tabId, scheduledSweepOpenedAt: Date.now() });
  } catch {
  }
}
async function closeScheduledSweepTab() {
  const { scheduledSweepWindowId, scheduledSweepTabId } = await chrome.storage.local.get(["scheduledSweepWindowId", "scheduledSweepTabId"]);
  await closeWorkWindow(scheduledSweepWindowId, scheduledSweepTabId);
  await chrome.storage.local.remove(["scheduledSweepWindowId", "scheduledSweepTabId", "scheduledSweepOpenedAt"]);
}
async function maybeRunSweepInBackground(tasks) {
  const runNowAt = tasks.limits?.runNowAt;
  if (!runNowAt) {
    await closeSweepTab();
    return;
  }
  const { sweepHandledAt, sweepTabOpenedAt } = await chrome.storage.local.get(["sweepHandledAt", "sweepTabOpenedAt"]);
  if (sweepHandledAt === runNowAt) {
    if (sweepTabOpenedAt && Date.now() - sweepTabOpenedAt > 4 * 6e4) await closeSweepTab();
    return;
  }
  await closeSweepTab();
  try {
    const { windowId, tabId } = await openWorkWindow("https://www.threads.com/messages/");
    await chrome.storage.local.set({ sweepHandledAt: runNowAt, sweepWindowId: windowId, sweepTabId: tabId, sweepTabOpenedAt: Date.now() });
  } catch {
  }
}
async function closeSweepTab() {
  const { sweepWindowId, sweepTabId } = await chrome.storage.local.get(["sweepWindowId", "sweepTabId"]);
  await closeWorkWindow(sweepWindowId, sweepTabId);
  await chrome.storage.local.remove(["sweepWindowId", "sweepTabId", "sweepTabOpenedAt"]);
}
async function maybeRunResearchInBackground(tasks) {
  const { researchHandledAt, researchTabOpenedAt, researchTabId } = await chrome.storage.local.get(["researchHandledAt", "researchTabOpenedAt", "researchTabId"]);
  if (researchTabId != null && researchTabOpenedAt && Date.now() - researchTabOpenedAt > 5 * 6e4) await closeResearchTab();
  const r = tasks.research;
  const runAt = r?.runAt;
  if (!runAt) {
    console.log("[threadhunt] research: \u043D\u0435\u0442 runAt \u0432 \u0437\u0430\u0434\u0430\u0447\u0430\u0445 (\u0441\u0435\u0440\u0432\u0435\u0440 \u043D\u0435 \u043E\u0442\u0434\u0430\u043B \xAB\u0441\u043E\u0431\u0440\u0430\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441\xBB). research:", r);
    return;
  }
  if (researchHandledAt === runAt) return;
  if (!r?.enabled || !r.queries?.length) {
    console.log("[threadhunt] research: \u043D\u0435\u0447\u0435\u0433\u043E \u0438\u0441\u043A\u0430\u0442\u044C \u2014 enabled:", r?.enabled, "queries:", r?.queries?.length);
    await chrome.storage.local.set({ researchHandledAt: runAt });
    void authed("/api/agent/research", { method: "POST", body: JSON.stringify({ posts: [], done: true }) }).then(() => void tick());
    return;
  }
  await closeResearchTab();
  console.log("[threadhunt] research: \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u044E \u0424\u041E\u041D\u041E\u0412\u0423\u042E \u0432\u043A\u043B\u0430\u0434\u043A\u0443 \u043F\u043E\u0438\u0441\u043A\u0430,", r.queries.length, "\u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432; \u043F\u0435\u0440\u0432\u044B\u0439:", r.queries[0]?.query);
  try {
    const queue = r.queries.slice(0, 12);
    await chrome.storage.session.set({ research: { queue, idx: 0, maxPerQuery: r.maxPerQuery || 15, collected: 0 }, lastResearchRunNow: Date.parse(runAt) });
    const url = "https://www.threads.com/search?q=" + encodeURIComponent(queue[0].query) + "&serp_type=default";
    const { windowId, tabId } = await openWorkWindow(url);
    await chrome.storage.local.set({ researchHandledAt: runAt, researchWindowId: windowId, researchTabId: tabId, researchTabOpenedAt: Date.now() });
  } catch {
  }
}
async function closeResearchTab() {
  const { researchWindowId, researchTabId } = await chrome.storage.local.get(["researchWindowId", "researchTabId"]);
  if (researchWindowId != null) {
    try {
      await chrome.windows.remove(researchWindowId);
    } catch {
    }
  } else if (researchTabId != null) {
    try {
      await chrome.tabs.remove(researchTabId);
    } catch {
    }
  }
  await chrome.storage.local.remove(["researchWindowId", "researchTabId", "researchTabOpenedAt"]);
}
async function maybeRunTestInBackground(tasks) {
  const dmTestAt = tasks.dmTestAt;
  if (!dmTestAt) {
    await closeTestTab();
    return;
  }
  const { testHandledAt, testTabOpenedAt } = await chrome.storage.local.get(["testHandledAt", "testTabOpenedAt"]);
  if (testHandledAt === dmTestAt) {
    if (testTabOpenedAt && Date.now() - testTabOpenedAt > 4 * 6e4) await closeTestTab();
    return;
  }
  await closeTestTab();
  try {
    const { windowId, tabId } = await openWorkWindow("https://www.threads.com/messages/");
    await chrome.storage.local.set({ testHandledAt: dmTestAt, testWindowId: windowId, testTabId: tabId, testTabOpenedAt: Date.now() });
  } catch {
  }
}
async function closeTestTab() {
  const { testWindowId, testTabId } = await chrome.storage.local.get(["testWindowId", "testTabId"]);
  await closeWorkWindow(testWindowId, testTabId);
  await chrome.storage.local.remove(["testWindowId", "testTabId", "testTabOpenedAt"]);
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "heartbeat") {
    void chrome.storage.local.set({ threadsLoggedIn: !!msg.threadsLoggedIn });
    void authed("/api/agent/heartbeat", {
      method: "POST",
      body: JSON.stringify({ version: VERSION, threadsLoggedIn: !!msg.threadsLoggedIn })
    });
  }
  if (msg?.type === "events") {
    const events = msg.events;
    void authed("/api/agent/events", { method: "POST", body: JSON.stringify({ events }) }).then(() => {
      void tick();
    });
  }
  if (msg?.type === "pass") {
    void authed("/api/agent/pass", { method: "POST", body: JSON.stringify(msg.report || {}) }).then(() => {
      void tick();
    });
    void closeScheduledSweepTab();
  }
  if (msg?.type === "cmd") {
    console.log("[threadhunt] \u043A\u043E\u043C\u0430\u043D\u0434\u0430 \u0438\u0437 \u0434\u0430\u0448\u0431\u043E\u0440\u0434\u0430:", msg.cmd, "\u2192 tick()");
    void tick();
  }
  if (msg?.type === "research") {
    void authed("/api/agent/research", { method: "POST", body: JSON.stringify({ posts: msg.posts || [], diag: msg.diag || null }) });
  }
  if (msg?.type === "researchDone") {
    void authed("/api/agent/research", { method: "POST", body: JSON.stringify({ posts: [], done: true }) }).then(() => void tick());
    void closeResearchTab();
  }
  if (msg?.type === "testResult") {
    void authed("/api/agent/test-result", { method: "POST", body: JSON.stringify({ scanned: msg.scanned || 0, matched: msg.matched || 0 }) }).then(() => void tick());
    void closeTestTab();
  }
  if (msg?.type === "getTasks") {
    chrome.storage.local.get("tasks").then((s) => sendResponse(s.tasks || null));
    return true;
  }
});
void tick();
