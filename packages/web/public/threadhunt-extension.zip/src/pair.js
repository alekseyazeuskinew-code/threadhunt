"use strict";
(() => {
  // src/pair.ts
  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const data = e.data;
    if (!data) return;
    if (data.source === "threadhunt-pair" && data.token) {
      chrome.storage.local.set({ token: data.token, api: data.api || "http://localhost:3010" }, () => {
        window.postMessage({ source: "threadhunt-paired" }, e.origin);
      });
      return;
    }
    if (data.source === "threadhunt-cmd" && data.cmd) {
      try {
        chrome.runtime.sendMessage({ type: "cmd", cmd: data.cmd });
      } catch {
      }
    }
  });
  window.postMessage({ source: "threadhunt-present" }, location.origin);
})();
