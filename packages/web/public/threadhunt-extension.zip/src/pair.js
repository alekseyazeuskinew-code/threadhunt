"use strict";
(() => {
  // src/pair.ts
  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const data = e.data;
    if (!data || data.source !== "threadhunt-pair" || !data.token) return;
    chrome.storage.local.set({ token: data.token, api: data.api || "http://localhost:3010" }, () => {
      window.postMessage({ source: "threadhunt-paired" }, e.origin);
    });
  });
  window.postMessage({ source: "threadhunt-present" }, location.origin);
})();
