"use strict";
(() => {
  // ../shared/src/keywords.ts
  function normalize(text) {
    return (text || "").toLowerCase().replace(/ё/g, "\u0435");
  }
  function matchKeyword(text, keywords) {
    const norm = normalize(text);
    for (const kw of keywords) {
      const needle = normalize(kw.text);
      if (!needle) continue;
      const mode = kw.mode ?? "root";
      if (mode === "root" && norm.includes(needle)) return kw.text;
      if (mode === "exact" && norm.trim() === needle.trim()) return kw.text;
      if (mode === "word") {
        const esc = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const re = new RegExp(`(^|[^a-z\u0430-\u044F0-9_])${esc}([^a-z\u0430-\u044F0-9_]|$)`, "i");
        if (re.test(norm)) return kw.text;
      }
    }
    return null;
  }

  // src/content.ts
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var BASE = location.origin;
  function pickReply(kw, replyBySearch) {
    if (kw.replyText && kw.replyText.trim()) return { text: kw.replyText.trim() };
    const tpl = replyBySearch[kw.searchId];
    return tpl ? { id: tpl.id, text: tpl.text } : null;
  }
  var SECTIONS = [
    { url: "/messages/requests", label: "requests" },
    { url: "/messages/hidden", label: "hidden" },
    { url: "/messages/", label: "main" }
  ];
  function activeSections(sections) {
    if (!sections) return SECTIONS.map((s) => ({ ...s }));
    const on = { requests: sections.requests, hidden: sections.hidden, main: sections.main };
    const picked = SECTIONS.filter((s) => on[s.label]).map((s) => ({ ...s }));
    return picked.length ? picked : SECTIONS.map((s) => ({ ...s }));
  }
  function withinWorkingHours(wh) {
    if (!wh.enabled) return true;
    const d = /* @__PURE__ */ new Date();
    const cur = d.getHours() * 60 + d.getMinutes();
    const [fh, fm] = wh.from.split(":").map(Number);
    const [th, tm] = wh.to.split(":").map(Number);
    const from = fh * 60 + fm;
    const to = th * 60 + tm;
    return from <= to ? cur >= from && cur <= to : cur >= from || cur <= to;
  }
  var SWEEP_KEY = "sweep";
  var LAST_SWEEP_KEY = "lastSweepAt";
  var TEST_RESULT_KEY = "th_test_result";
  async function getSweep() {
    const s = await chrome.storage.session.get(SWEEP_KEY);
    return s[SWEEP_KEY] || null;
  }
  async function setSweep(sw) {
    if (sw) await chrome.storage.session.set({ [SWEEP_KEY]: sw });
    else await chrome.storage.session.remove(SWEEP_KEY);
  }
  function isLoggedIn() {
    return !!document.querySelector('a[href^="/messages"]') || location.pathname.startsWith("/messages");
  }
  async function scrollList(times = 3) {
    for (let i = 0; i < times; i++) {
      const cands = [...document.querySelectorAll("div")].filter((d) => {
        const cs = getComputedStyle(d);
        return /auto|scroll/.test(cs.overflowY) && d.scrollHeight > d.clientHeight + 50;
      });
      for (const c of cands) c.scrollTop = c.scrollHeight;
      await sleep(900);
    }
  }
  function collectChats(section) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const a of document.querySelectorAll('a[href^="/messages/t/"]')) {
      const href = a.getAttribute("href") || "";
      const id = (href.match(/\/t\/(\d+)/) || [])[1];
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const raw = a.innerText || "";
      const name = raw.split("\n")[0].trim();
      const preview = raw.replace(/\s+/g, " ").trim();
      out.push({ id, href, name, preview, section });
    }
    return out;
  }
  function readLastMessage(forceIncoming = false) {
    const input = document.querySelector('[contenteditable="true"][role="textbox"]');
    let col = input;
    for (let i = 0; i < 6 && col; i++) col = col.parentElement;
    const colRect = col ? col.getBoundingClientRect() : { x: 0, width: window.innerWidth };
    const inputTop = input ? input.getBoundingClientRect().top : Infinity;
    const nodes = [...document.querySelectorAll('div[dir="auto"], span[dir="auto"]')].filter(
      (e) => e.innerText && e.innerText.trim().length > 1
    );
    const msgs = [];
    const seen = /* @__PURE__ */ new Set();
    for (const b of nodes) {
      const t = b.innerText.trim().replace(/\s+/g, " ");
      if (/^\w{3,9} \d{1,2}, \d{4}/.test(t)) continue;
      if (t === "Message unavailable") continue;
      if (t.length < 24 && (ACCEPT_RX.test(t) || DECLINE_RX.test(t))) continue;
      const r = b.getBoundingClientRect();
      if (r.bottom > inputTop + 5) continue;
      const leftGap = r.x - colRect.x;
      const rightGap = colRect.x + colRect.width - (r.x + r.width);
      if (leftGap < -20) continue;
      if (Math.min(leftGap, rightGap) >= 150) continue;
      const key = t.slice(0, 60);
      if (seen.has(key)) continue;
      seen.add(key);
      msgs.push({ text: t, incoming: forceIncoming ? true : leftGap < rightGap });
    }
    return msgs.length ? msgs[msgs.length - 1] : null;
  }
  var ACCEPT_RX = /(accept|accetta|aceptar|aceitar|accepter|akzeptier|allow|consenti|permett|permitir|autoriser|zulassen|unhide|mostra|unblock|onayla|kabul|akcept|прийн|дозвол|принять|разреш|показать|разблок|қабыл|рұқсат|рұқсат бер)/i;
  var DECLINE_RX = /(decline|delete|reject|block|remove|rifiuta|elimina|rechazar|recusar|refuser|ablehnen|löschen|supprimer|eliminar|engelle|reddet|sil|відхил|видалити|заблок|отклон|удалить|удали|жою|бас тарт)/i;
  var CONFIRM_RX = /^(ok|okay|got it|continue|next|confirm|done|conferma|continua|continuar|continuer|weiter|fortfahren|aceptar|entendido|понятно|продолжить|далее|хорошо|подтвердить|зрозуміло|продовжити|далі|tamam|anladım|devam|jatka|fortsätt|확인|계속|确定|继续|了解|わかりました|続行|түсінікті|жалғастыру)$/i;
  function isFilled(el) {
    const bg = getComputedStyle(el).backgroundColor;
    return !!bg && bg !== "transparent" && bg !== "rgba(0, 0, 0, 0)";
  }
  function visibleButtons() {
    return [...document.querySelectorAll('[role="button"], button')].filter((b) => {
      const t = (b.innerText || "").trim();
      return b.offsetParent !== null && t.length > 0 && t.length < 24;
    });
  }
  function clickConfirm() {
    const b = visibleButtons().find((x) => CONFIRM_RX.test((x.innerText || "").trim()));
    if (b) {
      b.click();
      return true;
    }
    return false;
  }
  function clickAccept() {
    const buttons = visibleButtons();
    let target = buttons.find((b) => ACCEPT_RX.test(b.innerText) && !DECLINE_RX.test(b.innerText));
    if (!target) target = buttons.find((b) => !DECLINE_RX.test(b.innerText) && !CONFIRM_RX.test(b.innerText) && isFilled(b));
    if (target) {
      target.click();
      return true;
    }
    return false;
  }
  async function acceptRequestIfNeeded() {
    let accepted = false;
    for (let i = 0; i < 8 && !accepted; i++) {
      clickConfirm();
      if (clickAccept()) accepted = true;
      else await sleep(1100);
    }
    if (accepted) {
      await sleep(1400);
      clickConfirm();
      await sleep(1600);
    }
  }
  async function sendReply(text) {
    try {
      const inputs = document.querySelectorAll('[contenteditable="true"][role="textbox"]');
      const input = inputs[inputs.length - 1];
      if (!input) return false;
      input.focus();
      document.execCommand("insertText", false, text);
      await sleep(500);
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      await sleep(1500);
      return true;
    } catch {
      return false;
    }
  }
  function navigate(path) {
    location.assign(BASE + path);
  }
  async function step() {
    if (!location.pathname.startsWith("/messages")) return;
    chrome.runtime.sendMessage({ type: "heartbeat", threadsLoggedIn: isLoggedIn() });
    let sweep = await getSweep();
    if (!sweep) {
      const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
      if (!tasks?.active || !tasks.searches.length) return;
      if (await maybeStartDmTest(tasks)) return;
      const lim = tasks.limits;
      const sections = activeSections(lim?.sections);
      const safe = !!lim?.safeMode;
      const { [LAST_SWEEP_KEY]: last, lastRunNow } = await chrome.storage.session.get([LAST_SWEEP_KEY, "lastRunNow"]);
      const runNowTs = lim?.runNowAt ? Date.parse(lim.runNowAt) : 0;
      const isRunNow = !!runNowTs && runNowTs !== lastRunNow;
      if (!isRunNow) {
        if (lim && !withinWorkingHours(lim.workingHours)) return;
        if (lim && lim.repliesRemainingToday <= 0 && !safe) return;
        const cooldownMs = Math.max(30, lim?.sweepIntervalMinutes ?? 180) * 6e4;
        if (last && Date.now() - last < cooldownMs) return;
      }
      if (isRunNow) await chrome.storage.session.set({ lastRunNow: runNowTs });
      sweep = {
        phase: "warmup",
        sectionIdx: 0,
        seenIds: [],
        chats: [],
        processIdx: 0,
        events: [],
        keywords: tasks.searches.flatMap((s) => s.keywords.map((k) => ({ ...k, searchId: s.searchId }))),
        replyBySearch: Object.fromEntries(tasks.searches.map((s) => [s.searchId, s.replyTemplates[0]])),
        repliedKeys: tasks.searches.flatMap((s) => s.alreadyReplied),
        minDelayMs: lim?.minDelayMs ?? 8e3,
        maxDialogs: lim?.maxDialogs ?? 40,
        repliesLeft: lim?.repliesRemainingToday ?? 40,
        sent: 0,
        expectPath: "/messages/",
        // прогрев перед заходом в Запросы (D.10)
        guard: 0,
        sections,
        dryRun: safe,
        // безопасный режим = не отправляем
        reportPass: true,
        // реальный/безопасный проход — шлём статистику серверу
        scanned: 0
      };
      await setSweep(sweep);
      navigate("/messages/");
      return;
    }
    if (sweep.phase === "warmup") {
      await sleep(2500);
      sweep.phase = "collect";
      sweep.sectionIdx = 0;
      sweep.expectPath = sweep.sections[0].url;
      sweep.guard = 0;
      await setSweep(sweep);
      navigate(sweep.sections[0].url);
      return;
    }
    if (!location.pathname.startsWith(sweep.expectPath.replace(/\/$/, "")) && sweep.guard < 3) {
      sweep.guard++;
      await setSweep(sweep);
      navigate(sweep.expectPath);
      return;
    }
    if (sweep.phase === "collect") {
      const sec = sweep.sections[sweep.sectionIdx];
      await sleep(3500);
      await scrollList();
      const seen = new Set(sweep.seenIds);
      const repliedKeys = new Set(sweep.repliedKeys);
      for (const c of collectChats(sec.label)) {
        if (seen.has(c.id) || repliedKeys.has(c.id)) continue;
        seen.add(c.id);
        if (c.section !== "main") {
          sweep.scanned = (sweep.scanned || 0) + 1;
          const m = matchKeyword(c.preview, sweep.keywords);
          if (!m) continue;
          const kw = sweep.keywords.find((k) => k.text === m);
          c.matched = { keyword: m, searchId: kw.searchId, replyText: kw.replyText };
          if (sweep.dryRun) {
            const tpl = pickReply(kw, sweep.replyBySearch);
            if (tpl)
              sweep.events.push({ searchId: kw.searchId, fromUserKey: c.id, fromUsername: c.name, matchedKeyword: m, templateId: tpl.id, sent: false, section: c.section, at: (/* @__PURE__ */ new Date()).toISOString() });
            continue;
          }
          if (sweep.chats.length >= sweep.maxDialogs) continue;
          sweep.chats.push(c);
        } else {
          if (sweep.chats.length >= sweep.maxDialogs) continue;
          sweep.chats.push(c);
        }
      }
      sweep.seenIds = [...seen];
      sweep.sectionIdx++;
      if (sweep.sectionIdx < sweep.sections.length) {
        sweep.expectPath = sweep.sections[sweep.sectionIdx].url;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.expectPath);
      } else {
        if (!sweep.chats.length) return finishSweep(sweep);
        sweep.phase = "process";
        sweep.processIdx = 0;
        sweep.expectPath = sweep.chats[0].href;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.chats[0].href);
      }
      return;
    }
    if (sweep.phase === "process") {
      const chat = sweep.chats[sweep.processIdx];
      await sleep(2500);
      if (chat.section !== "main" && chat.matched) {
        const kw = chat.matched;
        const tpl = pickReply(kw, sweep.replyBySearch);
        if (tpl) {
          await acceptRequestIfNeeded();
          const sent = await sendReply(tpl.text);
          if (sent) sweep.sent++;
          sweep.events.push({
            searchId: kw.searchId,
            fromUserKey: chat.id,
            fromUsername: chat.name,
            matchedKeyword: kw.keyword,
            templateId: tpl.id,
            sent,
            section: chat.section,
            at: (/* @__PURE__ */ new Date()).toISOString()
          });
          await sleep(sweep.minDelayMs);
          if (sweep.sent >= sweep.repliesLeft) return finishSweep(sweep);
        }
      } else {
        sweep.scanned = (sweep.scanned || 0) + 1;
        const last = readLastMessage(false);
        if (last && last.incoming) {
          const matched = matchKeyword(last.text, sweep.keywords);
          if (matched) {
            const kw = sweep.keywords.find((k) => k.text === matched);
            const tpl = pickReply(kw, sweep.replyBySearch);
            if (tpl) {
              let sent = false;
              if (!sweep.dryRun) {
                sent = await sendReply(tpl.text);
                if (sent) sweep.sent++;
              }
              sweep.events.push({
                searchId: kw.searchId,
                fromUserKey: chat.id,
                fromUsername: chat.name,
                matchedKeyword: matched,
                templateId: tpl.id,
                sent,
                section: chat.section,
                at: (/* @__PURE__ */ new Date()).toISOString()
              });
              if (!sweep.dryRun) {
                await sleep(sweep.minDelayMs);
                if (sweep.sent >= sweep.repliesLeft) return finishSweep(sweep);
              }
            }
          }
        }
      }
      sweep.processIdx++;
      if (sweep.processIdx < sweep.chats.length) {
        sweep.expectPath = sweep.chats[sweep.processIdx].href;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.chats[sweep.processIdx].href);
      } else {
        finishSweep(sweep);
      }
      return;
    }
  }
  async function finishSweep(sweep) {
    if (sweep.serverTest) {
      chrome.runtime.sendMessage({ type: "testResult", scanned: sweep.scanned || 0, matched: sweep.events.length });
      await chrome.storage.session.set({ [LAST_SWEEP_KEY]: Date.now() });
      await setSweep(null);
      return;
    }
    if (!sweep.dryRun) {
      if (sweep.events.length) chrome.runtime.sendMessage({ type: "events", events: sweep.events });
    } else if (!sweep.reportPass) {
      await chrome.storage.local.set({
        [TEST_RESULT_KEY]: { scanned: sweep.scanned || 0, matched: sweep.events.length, at: (/* @__PURE__ */ new Date()).toISOString(), done: true }
      });
    }
    if (sweep.reportPass) {
      chrome.runtime.sendMessage({
        type: "pass",
        report: {
          scanned: sweep.scanned || 0,
          sent: sweep.sent || 0,
          matched: sweep.events.length,
          sections: sweep.sections.map((s) => s.label).join(","),
          dryRun: !!sweep.dryRun
        }
      });
    }
    await chrome.storage.session.set({ [LAST_SWEEP_KEY]: Date.now() });
    await setSweep(null);
  }
  async function startTestSweep() {
    if (!location.pathname.startsWith("/messages")) return { ok: false, reason: "not_messages" };
    if (await getSweep()) return { ok: false, reason: "busy" };
    const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
    const searches = tasks?.searches || [];
    const keywords = searches.flatMap((s) => s.keywords.map((k) => ({ ...k, searchId: s.searchId })));
    if (!keywords.length) return { ok: false, reason: "no_keywords" };
    await chrome.storage.local.set({ [TEST_RESULT_KEY]: { scanned: 0, matched: 0, at: (/* @__PURE__ */ new Date()).toISOString(), done: false } });
    const sweep = {
      phase: "warmup",
      sectionIdx: 0,
      seenIds: [],
      chats: [],
      processIdx: 0,
      events: [],
      keywords,
      replyBySearch: Object.fromEntries(searches.map((s) => [s.searchId, s.replyTemplates[0]])),
      repliedKeys: [],
      // в тесте смотрим всех, даже тех, кому уже отвечали
      minDelayMs: 0,
      maxDialogs: tasks?.limits?.maxDialogs ?? 40,
      repliesLeft: 0,
      sent: 0,
      expectPath: "/messages/",
      // прогрев перед Запросами (D.10)
      guard: 0,
      dryRun: true,
      reportPass: false,
      // тест из popup: статистику на сервер НЕ шлём
      sections: activeSections(tasks?.limits?.sections),
      scanned: 0
    };
    await setSweep(sweep);
    navigate("/messages/");
    return { ok: true };
  }
  async function maybeStartDmTest(tasks) {
    if (!tasks.dmTestAt) return false;
    const ts = Date.parse(tasks.dmTestAt);
    if (!ts) return false;
    const { lastDmTest } = await chrome.storage.session.get("lastDmTest");
    if (ts === lastDmTest) return false;
    await chrome.storage.session.set({ lastDmTest: ts });
    const keywords = tasks.searches.flatMap((s) => s.keywords.map((k) => ({ ...k, searchId: s.searchId })));
    if (!keywords.length) {
      chrome.runtime.sendMessage({ type: "testResult", scanned: 0, matched: 0 });
      return true;
    }
    const sweep = {
      phase: "warmup",
      sectionIdx: 0,
      seenIds: [],
      chats: [],
      processIdx: 0,
      events: [],
      keywords,
      replyBySearch: Object.fromEntries(tasks.searches.map((s) => [s.searchId, s.replyTemplates[0]])),
      repliedKeys: [],
      minDelayMs: 0,
      maxDialogs: tasks.limits?.maxDialogs ?? 40,
      repliesLeft: 0,
      sent: 0,
      expectPath: "/messages/",
      guard: 0,
      dryRun: true,
      reportPass: false,
      sections: activeSections(tasks.limits?.sections),
      scanned: 0,
      serverTest: true
    };
    await setSweep(sweep);
    navigate("/messages/");
    return true;
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "startTest") {
      startTestSweep().then(sendResponse);
      return true;
    }
  });
  var RESEARCH_KEY = "research";
  var LAST_RESEARCH_KEY = "lastResearchAt";
  function searchUrl(q) {
    return `/search?q=${encodeURIComponent(q)}&serp_type=default`;
  }
  async function getResearch() {
    const s = await chrome.storage.session.get(RESEARCH_KEY);
    return s[RESEARCH_KEY] || null;
  }
  function parseCount(s) {
    const m = s.replace(/ /g, " ").match(/([\d][\d.,]*)\s*([KkКкMmМм]?)/);
    if (!m) return 0;
    let n = parseFloat(m[1].replace(/\s/g, "").replace(",", ".")) || 0;
    const suf = m[2].toLowerCase();
    if (suf === "k" || suf === "\u043A") n *= 1e3;
    if (suf === "m" || suf === "\u043C") n *= 1e6;
    return Math.round(n);
  }
  function collectSearchPosts(cur, max) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const a of document.querySelectorAll('a[href*="/post/"]')) {
      const href = a.getAttribute("href") || "";
      const m = href.match(/\/post\/([A-Za-z0-9_-]+)/);
      if (!m) continue;
      const id = m[1];
      if (seen.has(id)) continue;
      seen.add(id);
      let c = a;
      for (let i = 0; i < 9 && c; i++) c = c.parentElement;
      const container = c || a;
      const text = (container.innerText || "").replace(/\s+/g, " ").trim();
      if (text.length < 20) continue;
      const author = (href.match(/\/@([\w.]+)/) || [])[1] || void 0;
      let likes = 0, replies = 0, reposts = 0;
      for (const b of container.querySelectorAll("[aria-label]")) {
        const al = (b.getAttribute("aria-label") || "").toLowerCase();
        const num = parseCount(al);
        if (!num) continue;
        if (/like|нрав/.test(al)) likes = Math.max(likes, num);
        else if (/repl|comment|ответ|коммент/.test(al)) replies = Math.max(replies, num);
        else if (/repost|репост/.test(al)) reposts = Math.max(reposts, num);
      }
      out.push({ searchId: cur.searchId, query: cur.query, threadsPostId: id, author, text: text.slice(0, 1200), permalink: BASE + href.split("?")[0], likes, replies, reposts });
      if (out.length >= max) break;
    }
    return out;
  }
  async function researchTick() {
    if (location.pathname.startsWith("/search")) {
      const st = await getResearch();
      if (!st || st.idx >= st.queue.length) return;
      const cur = st.queue[st.idx];
      await sleep(3500);
      await scrollList(4);
      const posts = collectSearchPosts(cur, st.maxPerQuery);
      if (posts.length) chrome.runtime.sendMessage({ type: "research", posts });
      st.idx++;
      if (st.idx < st.queue.length) {
        await chrome.storage.session.set({ [RESEARCH_KEY]: st });
        navigate(searchUrl(st.queue[st.idx].query));
      } else {
        await chrome.storage.session.remove(RESEARCH_KEY);
        await chrome.storage.session.set({ [LAST_RESEARCH_KEY]: Date.now() });
        navigate("/messages/");
      }
      return;
    }
    if (!location.pathname.startsWith("/messages")) return;
    const existing = await getResearch();
    if (existing) {
      if (existing.idx < existing.queue.length) navigate(searchUrl(existing.queue[existing.idx].query));
      return;
    }
    if (await getSweep()) return;
    const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
    const r = tasks?.research;
    if (!r?.enabled || !r.queries?.length) return;
    const { [LAST_RESEARCH_KEY]: last } = await chrome.storage.session.get(LAST_RESEARCH_KEY);
    if (last && Date.now() - last < Math.max(60, r.intervalMinutes || 720) * 6e4) return;
    const state = { queue: r.queries.slice(0, 12), idx: 0, maxPerQuery: r.maxPerQuery || 15 };
    await chrome.storage.session.set({ [RESEARCH_KEY]: state });
    navigate(searchUrl(state.queue[0].query));
  }
  async function dmTestWatcher() {
    if (await getSweep()) return;
    const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
    if (tasks) await maybeStartDmTest(tasks);
  }
  void step();
  setInterval(() => void step(), 3e4);
  void researchTick();
  setInterval(() => void researchTick(), 6e4);
  void dmTestWatcher();
  setInterval(() => void dmTestWatcher(), 2e4);
})();
