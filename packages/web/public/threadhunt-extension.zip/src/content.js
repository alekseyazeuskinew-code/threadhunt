"use strict";
(() => {
  // ../shared/src/keywords.ts
  function normalize(text) {
    return (text || "").toLowerCase().replace(/ё/g, "\u0435");
  }
  function matchKeyword(text, keywords) {
    const norm = normalize(text);
    for (const kw of keywords) {
      const needle = normalize(kw.text);
      if (!needle) continue;
      const mode = kw.mode ?? "root";
      if (mode === "root" && norm.includes(needle)) return kw.text;
      if (mode === "exact" && norm.trim() === needle.trim()) return kw.text;
      if (mode === "word") {
        const esc = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const re = new RegExp(`(^|[^a-z\u0430-\u044F0-9_])${esc}([^a-z\u0430-\u044F0-9_]|$)`, "i");
        if (re.test(norm)) return kw.text;
      }
    }
    return null;
  }

  // src/content.ts
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var runtimeCalib = null;
  var hasLabel = (b, labels) => !!labels?.some((l) => l && b.innerText.toLowerCase().includes(l.toLowerCase()));
  var BASE = location.origin;
  function serverLog(text, level = "info") {
    try {
      chrome.runtime.sendMessage({ type: "log", level, text: text.slice(0, 300) });
    } catch {
    }
  }
  function pickReply(kw, replyBySearch) {
    if (kw.replyText && kw.replyText.trim()) return { text: kw.replyText.trim() };
    const e = replyBySearch[kw.searchId];
    const tpls = e?.templates?.filter((t) => t.text && t.text.trim()) || [];
    if (!tpls.length) return null;
    const tpl = tpls.length === 1 ? tpls[0] : tpls[Math.floor(Math.random() * tpls.length)];
    return { id: tpl.id, text: tpl.text };
  }
  function withObLink(text, base, chatId) {
    if (!base) return text;
    return `${text}

\u2192 \u0417\u0430\u043F\u043E\u043B\u043D\u0438 \u043A\u043E\u0440\u043E\u0442\u043A\u0443\u044E \u0430\u043D\u043A\u0435\u0442\u0443: ${base}${encodeURIComponent(chatId)}`;
  }
  var SECTIONS = [
    { url: "/messages/requests", label: "requests" },
    { url: "/messages/hidden", label: "hidden" },
    { url: "/messages/", label: "main" }
  ];
  function sectionRu(label) {
    return label === "requests" ? "\u0417\u0430\u043F\u0440\u043E\u0441\u044B" : label === "hidden" ? "\u0421\u043A\u0440\u044B\u0442\u044B\u0435" : "\u041E\u0441\u043D\u043E\u0432\u043D\u043E\u0439 \u0434\u0438\u0440\u0435\u043A\u0442";
  }
  function activeSections(sections) {
    if (!sections) return SECTIONS.map((s) => ({ ...s }));
    const on = { requests: sections.requests, hidden: sections.hidden, main: sections.main };
    const picked = SECTIONS.filter((s) => on[s.label]).map((s) => ({ ...s }));
    return picked.length ? picked : SECTIONS.map((s) => ({ ...s }));
  }
  function withinWorkingHours(wh) {
    if (!wh.enabled) return true;
    const d = /* @__PURE__ */ new Date();
    const cur = d.getHours() * 60 + d.getMinutes();
    const [fh, fm] = wh.from.split(":").map(Number);
    const [th, tm] = wh.to.split(":").map(Number);
    const from = fh * 60 + fm;
    const to = th * 60 + tm;
    return from <= to ? cur >= from && cur <= to : cur >= from || cur <= to;
  }
  var SWEEP_KEY = "sweep";
  var LAST_SWEEP_KEY = "lastSweepAt";
  var TEST_RESULT_KEY = "th_test_result";
  async function getSweep() {
    const s = await chrome.storage.session.get(SWEEP_KEY);
    return s[SWEEP_KEY] || null;
  }
  async function setSweep(sw) {
    if (sw) await chrome.storage.session.set({ [SWEEP_KEY]: sw });
    else await chrome.storage.session.remove(SWEEP_KEY);
  }
  function isLoggedIn() {
    return !!document.querySelector('a[href^="/messages"]') || location.pathname.startsWith("/messages");
  }
  async function scrollList(times = 3) {
    for (let i = 0; i < times; i++) {
      const cands = [...document.querySelectorAll("div")].filter((d) => {
        const cs = getComputedStyle(d);
        return /auto|scroll/.test(cs.overflowY) && d.scrollHeight > d.clientHeight + 50;
      });
      for (const c of cands) c.scrollTop = c.scrollHeight;
      window.scrollTo(0, document.body.scrollHeight);
      document.scrollingElement?.scrollTo(0, document.scrollingElement.scrollHeight);
      await sleep(900);
    }
  }
  function collectChats(section) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const a of document.querySelectorAll('a[href^="/messages/t/"]')) {
      const href = a.getAttribute("href") || "";
      const id = (href.match(/\/t\/(\d+)/) || [])[1];
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const raw = a.innerText || "";
      const name = raw.split("\n")[0].trim();
      const preview = raw.replace(/\s+/g, " ").trim();
      out.push({ id, href, name, preview, section });
    }
    return out;
  }
  function readLastMessage(forceIncoming = false) {
    const input = document.querySelector('[contenteditable="true"][role="textbox"]');
    let col = input;
    for (let i = 0; i < 6 && col; i++) col = col.parentElement;
    const colRect = col ? col.getBoundingClientRect() : { x: 0, width: window.innerWidth };
    const inputTop = input ? input.getBoundingClientRect().top : Infinity;
    const nodes = [...document.querySelectorAll('div[dir="auto"], span[dir="auto"]')].filter(
      (e) => e.innerText && e.innerText.trim().length > 1
    );
    const msgs = [];
    const seen = /* @__PURE__ */ new Set();
    for (const b of nodes) {
      const t = b.innerText.trim().replace(/\s+/g, " ");
      if (/^\w{3,9} \d{1,2}, \d{4}/.test(t)) continue;
      if (t === "Message unavailable") continue;
      if (t.length < 24 && (ACCEPT_RX.test(t) || DECLINE_RX.test(t))) continue;
      const r = b.getBoundingClientRect();
      if (r.bottom > inputTop + 5) continue;
      const leftGap = r.x - colRect.x;
      const rightGap = colRect.x + colRect.width - (r.x + r.width);
      if (leftGap < -20) continue;
      if (Math.min(leftGap, rightGap) >= 150) continue;
      const key = t.slice(0, 60);
      if (seen.has(key)) continue;
      seen.add(key);
      msgs.push({ text: t, incoming: forceIncoming ? true : leftGap < rightGap });
    }
    return msgs.length ? msgs[msgs.length - 1] : null;
  }
  var ACCEPT_RX = /(accept|accetta|aceptar|aceitar|accepter|akzeptier|allow|consenti|permett|permitir|autoriser|zulassen|unhide|mostra|unblock|onayla|kabul|akcept|прийн|дозвол|принять|разреш|показать|разблок|қабыл|рұқсат|рұқсат бер)/i;
  var DECLINE_RX = /(decline|delete|reject|block|remove|rifiuta|elimina|rechazar|recusar|refuser|ablehnen|löschen|supprimer|eliminar|engelle|reddet|sil|відхил|видалити|заблок|отклон|удалить|удали|жою|бас тарт)/i;
  var CONFIRM_RX = /^(ok|okay|got it|continue|next|confirm|done|conferma|continua|continuar|continuer|weiter|fortfahren|aceptar|entendido|понятно|продолжить|далее|хорошо|подтвердить|зрозуміло|продовжити|далі|tamam|anladım|devam|jatka|fortsätt|확인|계속|确定|继续|了解|わかりました|続行|түсінікті|жалғастыру)$/i;
  function isFilled(el) {
    const bg = getComputedStyle(el).backgroundColor;
    return !!bg && bg !== "transparent" && bg !== "rgba(0, 0, 0, 0)";
  }
  function visibleButtons() {
    return [...document.querySelectorAll('[role="button"], button')].filter((b) => {
      const t = (b.innerText || "").trim();
      return b.offsetParent !== null && t.length > 0 && t.length < 24;
    });
  }
  function diagButtons() {
    return [...document.querySelectorAll('[role="button"], button')].filter((b) => b.offsetParent !== null).map((b) => ((b.innerText || "").trim() || b.getAttribute("aria-label") || "").replace(/\s+/g, " ")).filter((t) => t && t.length < 30).slice(0, 14).join(" | ").slice(0, 240);
  }
  function clickConfirm() {
    const buttons = visibleButtons();
    if (runtimeCalib?.dismissLabels?.length) {
      const c = buttons.find((x) => hasLabel(x, runtimeCalib.dismissLabels));
      if (c) {
        c.click();
        return true;
      }
    }
    const b = buttons.find((x) => CONFIRM_RX.test((x.innerText || "").trim()));
    if (b) {
      b.click();
      return true;
    }
    return false;
  }
  async function dismissWelcome(tries = 3) {
    for (let i = 0; i < tries; i++) {
      if (clickConfirm()) {
        await sleep(1200);
        return;
      }
      await sleep(700);
    }
  }
  function clickAccept() {
    const buttons = visibleButtons();
    const isDecline = (b) => DECLINE_RX.test(b.innerText) || hasLabel(b, runtimeCalib?.declineLabels);
    if (runtimeCalib) {
      const t = buttons.find((b) => (hasLabel(b, runtimeCalib.acceptLabels) || hasLabel(b, runtimeCalib.unhideLabels)) && !isDecline(b));
      if (t) {
        t.click();
        return true;
      }
    }
    let target = buttons.find((b) => ACCEPT_RX.test(b.innerText) && !isDecline(b));
    if (!target) target = buttons.find((b) => !isDecline(b) && !CONFIRM_RX.test(b.innerText) && isFilled(b));
    if (target) {
      target.click();
      return true;
    }
    return false;
  }
  async function acceptRequestIfNeeded() {
    for (let i = 0; i < 10; i++) {
      const input = document.querySelector('[contenteditable="true"][role="textbox"]');
      if (input && input.offsetParent !== null) return;
      clickConfirm();
      clickAccept();
      await sleep(1300);
    }
  }
  async function sendReply(text) {
    try {
      let input = null;
      for (let i = 0; i < 16; i++) {
        const inputs = document.querySelectorAll('[contenteditable="true"][role="textbox"]');
        input = inputs[inputs.length - 1] || null;
        if (input && input.offsetParent !== null) break;
        input = null;
        await sleep(500);
      }
      if (!input) return false;
      input.focus();
      document.execCommand("insertText", false, text);
      await sleep(500);
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      await sleep(1500);
      return true;
    } catch {
      return false;
    }
  }
  function navigate(path) {
    location.assign(BASE + path);
  }
  var BANNER_ID = "th-work-banner";
  async function showWorkBanner() {
    const { hideWorkBanner } = await chrome.storage.local.get("hideWorkBanner");
    if (hideWorkBanner) return;
    if (document.getElementById(BANNER_ID)) return;
    const bar = document.createElement("div");
    bar.id = BANNER_ID;
    bar.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#6d5cf6;color:#fff;font:600 14px/1.4 system-ui,sans-serif;padding:10px 16px;display:flex;align-items:center;justify-content:center;gap:12px;box-shadow:0 2px 12px rgba(0,0,0,.25)";
    const txt = document.createElement("span");
    txt.textContent = "\u{1F7E3} ThreadHunt \u0438\u0434\u0451\u0442 \u043F\u043E \u0434\u0438\u0440\u0435\u043A\u0442\u0443 \u2014 \u043D\u0435 \u0437\u0430\u043A\u0440\u044B\u0432\u0430\u0439\u0442\u0435 \u044D\u0442\u0443 \u0432\u043A\u043B\u0430\u0434\u043A\u0443, \u043E\u043D\u0430 \u0437\u0430\u043A\u0440\u043E\u0435\u0442\u0441\u044F \u0441\u0430\u043C\u0430.";
    const hide = document.createElement("button");
    hide.textContent = "\u041D\u0435 \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0442\u044C \u0441\u043D\u043E\u0432\u0430";
    hide.style.cssText = "background:rgba(255,255,255,.22);color:#fff;border:0;border-radius:8px;padding:6px 10px;font:600 12px system-ui;cursor:pointer";
    hide.onclick = () => {
      void chrome.storage.local.set({ hideWorkBanner: true });
      bar.remove();
    };
    bar.append(txt, hide);
    (document.body || document.documentElement).appendChild(bar);
  }
  function hideWorkBannerNow() {
    document.getElementById(BANNER_ID)?.remove();
  }
  var stepRunning = false;
  async function step() {
    if (stepRunning) return;
    if (!location.pathname.startsWith("/messages")) return;
    stepRunning = true;
    try {
      await stepInner();
    } finally {
      stepRunning = false;
    }
  }
  async function stepInner() {
    chrome.runtime.sendMessage({ type: "heartbeat", threadsLoggedIn: isLoggedIn() });
    let sweep = await getSweep();
    if (sweep) void showWorkBanner();
    else hideWorkBannerNow();
    if (sweep) {
      const t = await chrome.runtime.sendMessage({ type: "getTasks" });
      runtimeCalib = t?.calibration ?? runtimeCalib;
      const stopTs = t?.limits?.stopAt ? Date.parse(t.limits.stopAt) : 0;
      if (stopTs && stopTs >= sweep.startedAt) {
        serverLog("\u23F9 \u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E \u0432\u0440\u0443\u0447\u043D\u0443\u044E \u2014 \u043F\u0440\u043E\u0445\u043E\u0434 \u043F\u0440\u0435\u0440\u0432\u0430\u043D", "warn");
        return finishSweep(sweep);
      }
    }
    if (!sweep) {
      const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
      if (!tasks?.active || !tasks.searches.length) return;
      runtimeCalib = tasks.calibration ?? runtimeCalib;
      if (await getCalib()) return;
      if (await maybeStartDmTest(tasks)) return;
      const lim = tasks.limits;
      const sections = activeSections(lim?.sections);
      const safe = !!lim?.safeMode;
      const { [LAST_SWEEP_KEY]: last, lastRunNow } = await chrome.storage.session.get([LAST_SWEEP_KEY, "lastRunNow"]);
      const runNowTs = lim?.runNowAt ? Date.parse(lim.runNowAt) : 0;
      const isRunNow = !!runNowTs && runNowTs !== lastRunNow;
      if (!isRunNow) {
        if (lim && !withinWorkingHours(lim.workingHours)) return;
        if (lim && lim.repliesRemainingToday <= 0 && !safe) return;
        const cooldownMs = Math.max(30, lim?.sweepIntervalMinutes ?? 180) * 6e4;
        if (last && Date.now() - last < cooldownMs) return;
      }
      if (isRunNow) await chrome.storage.session.set({ lastRunNow: runNowTs });
      serverLog(safe ? "\u25B6 \u0421\u0442\u0430\u0440\u0442 \u043F\u0440\u043E\u0445\u043E\u0434\u0430 (\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u044B\u0439 \u0440\u0435\u0436\u0438\u043C \u2014 \u0431\u0435\u0437 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438)" : "\u25B6 \u0421\u0442\u0430\u0440\u0442 \u043F\u0440\u043E\u0445\u043E\u0434\u0430 \u043F\u043E \u0434\u0438\u0440\u0435\u043A\u0442\u0443");
      chrome.runtime.sendMessage({ type: "pass-start" });
      sweep = {
        phase: "warmup",
        startedAt: Date.now(),
        sectionIdx: 0,
        seenIds: [],
        chats: [],
        processIdx: 0,
        events: [],
        keywords: tasks.searches.flatMap((s) => s.keywords.map((k) => ({ ...k, searchId: s.searchId }))),
        replyBySearch: Object.fromEntries(tasks.searches.map((s) => [s.searchId, { templates: s.replyTemplates, rotation: s.rotation }])),
        obLinkBySearch: Object.fromEntries(tasks.searches.map((s) => [s.searchId, s.obLink])),
        repliedKeys: tasks.searches.flatMap((s) => s.alreadyReplied),
        minDelayMs: lim?.minDelayMs ?? 8e3,
        maxDialogs: lim?.maxDialogs ?? 40,
        repliesLeft: lim?.repliesRemainingToday ?? 40,
        sent: 0,
        expectPath: "/messages/",
        // прогрев перед заходом в Запросы (D.10)
        guard: 0,
        sections,
        dryRun: safe,
        // безопасный режим = не отправляем
        reportPass: true,
        // реальный/безопасный проход — шлём статистику серверу
        scanned: 0
      };
      await setSweep(sweep);
      navigate("/messages/");
      return;
    }
    if (sweep.phase === "warmup") {
      await sleep(2500);
      await dismissWelcome();
      sweep.phase = "collect";
      sweep.sectionIdx = 0;
      sweep.expectPath = sweep.sections[0].url;
      sweep.guard = 0;
      await setSweep(sweep);
      navigate(sweep.sections[0].url);
      return;
    }
    if (!location.pathname.startsWith(sweep.expectPath.replace(/\/$/, "")) && sweep.guard < 3) {
      sweep.guard++;
      await setSweep(sweep);
      navigate(sweep.expectPath);
      return;
    }
    if (sweep.phase === "collect") {
      const sec = sweep.sections[sweep.sectionIdx];
      await sleep(3500);
      await dismissWelcome();
      serverLog("\u{1F50E} \u0421\u043C\u043E\u0442\u0440\u044E \u0440\u0430\u0437\u0434\u0435\u043B: " + sectionRu(sec.label));
      await scrollList();
      const seen = new Set(sweep.seenIds);
      const repliedKeys = new Set(sweep.repliedKeys);
      for (const c of collectChats(sec.label)) {
        if (seen.has(c.id) || repliedKeys.has(c.id)) continue;
        seen.add(c.id);
        if (c.section !== "main") {
          sweep.scanned = (sweep.scanned || 0) + 1;
          const m = matchKeyword(c.preview, sweep.keywords);
          if (!m) continue;
          const kw = sweep.keywords.find((k) => k.text === m);
          c.matched = { keyword: m, searchId: kw.searchId, replyText: kw.replyText };
          if (sweep.dryRun) {
            const tpl = pickReply(kw, sweep.replyBySearch);
            if (tpl)
              sweep.events.push({ searchId: kw.searchId, fromUserKey: c.id, fromUsername: c.name, matchedKeyword: m, templateId: tpl.id, sent: false, section: c.section, at: (/* @__PURE__ */ new Date()).toISOString() });
            continue;
          }
          if (sweep.chats.length >= sweep.maxDialogs) continue;
          sweep.chats.push(c);
        } else {
          if (sweep.chats.length >= sweep.maxDialogs) continue;
          sweep.chats.push(c);
        }
      }
      sweep.seenIds = [...seen];
      sweep.sectionIdx++;
      if (sweep.sectionIdx < sweep.sections.length) {
        sweep.expectPath = sweep.sections[sweep.sectionIdx].url;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.expectPath);
      } else {
        if (!sweep.chats.length) return finishSweep(sweep);
        sweep.phase = "process";
        sweep.processIdx = 0;
        sweep.expectPath = sweep.chats[0].href;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.chats[0].href);
      }
      return;
    }
    if (sweep.phase === "process") {
      const chat = sweep.chats[sweep.processIdx];
      await sleep(2500);
      if (!sweep.attempted) sweep.attempted = [];
      const alreadyAttempted = sweep.attempted.includes(chat.id);
      if (!alreadyAttempted) {
        sweep.attempted.push(chat.id);
        await setSweep(sweep);
      }
      if (!alreadyAttempted && chat.section !== "main" && chat.matched) {
        const kw = chat.matched;
        const tpl = pickReply(kw, sweep.replyBySearch);
        if (tpl) {
          await acceptRequestIfNeeded();
          const sent = await sendReply(withObLink(tpl.text, sweep.obLinkBySearch[kw.searchId], chat.id));
          if (sent) sweep.sent++;
          if (sent) serverLog("\u2705 \u041E\u0442\u0432\u0435\u0442\u0438\u043B @" + (chat.name || "\u2014") + " \u043D\u0430 \xAB" + kw.keyword + "\xBB", "reply");
          else serverLog("\u26A0\uFE0F \u041D\u0435 \u0441\u043C\u043E\u0433 @" + (chat.name || "\u2014") + " (" + sectionRu(chat.section) + "). \u041A\u043D\u043E\u043F\u043A\u0438 \u043D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435: " + diagButtons(), "warn");
          const introMsg = chat.preview && chat.name && chat.preview.startsWith(chat.name) ? chat.preview.slice(chat.name.length).trim() : chat.preview;
          const ev = {
            searchId: kw.searchId,
            fromUserKey: chat.id,
            fromUsername: chat.name,
            matchedKeyword: kw.keyword,
            templateId: tpl.id,
            sent,
            section: chat.section,
            message: introMsg,
            at: (/* @__PURE__ */ new Date()).toISOString()
          };
          sweep.events.push(ev);
          chrome.runtime.sendMessage({ type: "events", events: [ev] });
          await sleep(sweep.minDelayMs);
          if (sweep.sent >= sweep.repliesLeft) return finishSweep(sweep);
        }
      } else if (!alreadyAttempted) {
        sweep.scanned = (sweep.scanned || 0) + 1;
        await dismissWelcome();
        const last = readLastMessage(false);
        if (last && last.incoming) {
          const matched = matchKeyword(last.text, sweep.keywords);
          if (matched) {
            const kw = sweep.keywords.find((k) => k.text === matched);
            const tpl = pickReply(kw, sweep.replyBySearch);
            if (tpl) {
              let sent = false;
              if (!sweep.dryRun) {
                sent = await sendReply(withObLink(tpl.text, sweep.obLinkBySearch[kw.searchId], chat.id));
                if (sent) sweep.sent++;
                if (sent) serverLog("\u2705 \u041E\u0442\u0432\u0435\u0442\u0438\u043B @" + (chat.name || "\u2014") + " \u043D\u0430 \xAB" + matched + "\xBB", "reply");
                else serverLog("\u26A0\uFE0F \u041D\u0435 \u0441\u043C\u043E\u0433 \u043E\u0442\u0432\u0435\u0442\u0438\u0442\u044C @" + (chat.name || "\u2014") + " \u2014 \u043F\u043E\u043B\u0435 \u0432\u0432\u043E\u0434\u0430 \u043D\u0435 \u043E\u0442\u043A\u0440\u044B\u043B\u043E\u0441\u044C", "warn");
              }
              const ev = {
                searchId: kw.searchId,
                fromUserKey: chat.id,
                fromUsername: chat.name,
                matchedKeyword: matched,
                templateId: tpl.id,
                sent,
                section: chat.section,
                message: last.text,
                // полное входящее сообщение кандидата
                at: (/* @__PURE__ */ new Date()).toISOString()
              };
              sweep.events.push(ev);
              if (!sweep.dryRun) chrome.runtime.sendMessage({ type: "events", events: [ev] });
              if (!sweep.dryRun) {
                await sleep(sweep.minDelayMs);
                if (sweep.sent >= sweep.repliesLeft) return finishSweep(sweep);
              }
            }
          }
        }
      }
      sweep.processIdx++;
      if (sweep.processIdx < sweep.chats.length) {
        sweep.expectPath = sweep.chats[sweep.processIdx].href;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.chats[sweep.processIdx].href);
      } else {
        finishSweep(sweep);
      }
      return;
    }
  }
  async function finishSweep(sweep) {
    serverLog(`\u25A0 \u041F\u0440\u043E\u0445\u043E\u0434 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D: \u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043E ${sweep.scanned || 0}, \u0441\u043E\u0432\u043F\u0430\u0434\u0435\u043D\u0438\u0439 ${sweep.events.length}, \u043E\u0442\u0432\u0435\u0442\u043E\u0432 ${sweep.sent || 0}`);
    if (sweep.serverTest) {
      chrome.runtime.sendMessage({ type: "testResult", scanned: sweep.scanned || 0, matched: sweep.events.length });
      await chrome.storage.session.set({ [LAST_SWEEP_KEY]: Date.now() });
      await setSweep(null);
      return;
    }
    if (!sweep.dryRun) {
      if (sweep.events.length) chrome.runtime.sendMessage({ type: "events", events: sweep.events });
    } else if (!sweep.reportPass) {
      await chrome.storage.local.set({
        [TEST_RESULT_KEY]: { scanned: sweep.scanned || 0, matched: sweep.events.length, at: (/* @__PURE__ */ new Date()).toISOString(), done: true }
      });
    }
    if (sweep.reportPass) {
      chrome.runtime.sendMessage({
        type: "pass",
        report: {
          scanned: sweep.scanned || 0,
          sent: sweep.sent || 0,
          matched: sweep.events.length,
          sections: sweep.sections.map((s) => s.label).join(","),
          dryRun: !!sweep.dryRun
        }
      });
    }
    await chrome.storage.session.set({ [LAST_SWEEP_KEY]: Date.now() });
    await setSweep(null);
  }
  async function startTestSweep() {
    if (!location.pathname.startsWith("/messages")) return { ok: false, reason: "not_messages" };
    if (await getSweep()) return { ok: false, reason: "busy" };
    const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
    const searches = tasks?.searches || [];
    const keywords = searches.flatMap((s) => s.keywords.map((k) => ({ ...k, searchId: s.searchId })));
    if (!keywords.length) return { ok: false, reason: "no_keywords" };
    await chrome.storage.local.set({ [TEST_RESULT_KEY]: { scanned: 0, matched: 0, at: (/* @__PURE__ */ new Date()).toISOString(), done: false } });
    const sweep = {
      phase: "warmup",
      startedAt: Date.now(),
      sectionIdx: 0,
      seenIds: [],
      chats: [],
      processIdx: 0,
      events: [],
      keywords,
      replyBySearch: Object.fromEntries(searches.map((s) => [s.searchId, { templates: s.replyTemplates, rotation: s.rotation }])),
      obLinkBySearch: Object.fromEntries(searches.map((s) => [s.searchId, s.obLink])),
      repliedKeys: [],
      // в тесте смотрим всех, даже тех, кому уже отвечали
      minDelayMs: 0,
      maxDialogs: tasks?.limits?.maxDialogs ?? 40,
      repliesLeft: 0,
      sent: 0,
      expectPath: "/messages/",
      // прогрев перед Запросами (D.10)
      guard: 0,
      dryRun: true,
      reportPass: false,
      // тест из popup: статистику на сервер НЕ шлём
      sections: activeSections(tasks?.limits?.sections),
      scanned: 0
    };
    await setSweep(sweep);
    navigate("/messages/");
    return { ok: true };
  }
  async function maybeStartDmTest(tasks) {
    if (!tasks.dmTestAt) return false;
    const ts = Date.parse(tasks.dmTestAt);
    if (!ts) return false;
    const { lastDmTest } = await chrome.storage.session.get("lastDmTest");
    if (ts === lastDmTest) return false;
    await chrome.storage.session.set({ lastDmTest: ts });
    const keywords = tasks.searches.flatMap((s) => s.keywords.map((k) => ({ ...k, searchId: s.searchId })));
    if (!keywords.length) {
      chrome.runtime.sendMessage({ type: "testResult", scanned: 0, matched: 0 });
      return true;
    }
    const sweep = {
      phase: "warmup",
      startedAt: Date.now(),
      sectionIdx: 0,
      seenIds: [],
      chats: [],
      processIdx: 0,
      events: [],
      keywords,
      replyBySearch: Object.fromEntries(tasks.searches.map((s) => [s.searchId, { templates: s.replyTemplates, rotation: s.rotation }])),
      obLinkBySearch: Object.fromEntries(tasks.searches.map((s) => [s.searchId, s.obLink])),
      repliedKeys: [],
      minDelayMs: 0,
      maxDialogs: tasks.limits?.maxDialogs ?? 40,
      repliesLeft: 0,
      sent: 0,
      expectPath: "/messages/",
      guard: 0,
      dryRun: true,
      reportPass: false,
      sections: activeSections(tasks.limits?.sections),
      scanned: 0,
      serverTest: true
    };
    await setSweep(sweep);
    navigate("/messages/");
    return true;
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "startTest") {
      startTestSweep().then(sendResponse);
      return true;
    }
  });
  var RESEARCH_KEY = "research";
  var LAST_RESEARCH_KEY = "lastResearchAt";
  function searchUrl(q) {
    return `/search?q=${encodeURIComponent(q)}&serp_type=default`;
  }
  async function getResearch() {
    const s = await chrome.storage.session.get(RESEARCH_KEY);
    return s[RESEARCH_KEY] || null;
  }
  function parseCount(s) {
    const m = s.replace(/ /g, " ").match(/([\d][\d.,]*)([KkКкMmМм])?/);
    if (!m) return 0;
    let n = parseFloat(m[1].replace(/\s/g, "").replace(",", ".")) || 0;
    const suf = (m[2] || "").toLowerCase();
    if (suf === "k" || suf === "\u043A") n *= 1e3;
    if (suf === "m" || suf === "\u043C") n *= 1e6;
    return Math.round(n);
  }
  function searchDiag(query, collected) {
    const sample = [...document.querySelectorAll('a[href*="/post/"]')].slice(0, 3).map((a) => a.getAttribute("href") || "");
    let htmlSample = "";
    let buttons = [];
    try {
      const firstLink = document.querySelector('a[href*="/post/"]');
      let node = firstLink;
      if (node) for (let i = 0; i < 10 && node.parentElement; i++) node = node.parentElement;
      const el = node || document.querySelector("main") || document.body;
      htmlSample = (el?.outerHTML || "").replace(/\s+/g, " ").slice(0, 12e3);
      if (node) {
        buttons = [...node.querySelectorAll('[role="button"]')].filter((b) => b.querySelector("svg")).slice(0, 10).map((b) => {
          const svg = b.querySelector("svg");
          const label = svg?.getAttribute("aria-label") || b.getAttribute("aria-label") || svg?.querySelector("title")?.textContent || "";
          return {
            label: label.slice(0, 40),
            text: (b.textContent || "").replace(/\s+/g, " ").trim().slice(0, 30),
            next: (b.nextElementSibling?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 30)
          };
        });
      }
    } catch {
    }
    let ext = "";
    try {
      ext = chrome.runtime.getManifest().version;
    } catch {
    }
    return {
      q: query,
      ext,
      url: location.pathname + location.search,
      postLinks: document.querySelectorAll('a[href*="/post/"]').length,
      userPostLinks: document.querySelectorAll('a[href*="/@"][href*="/post/"]').length,
      pressable: document.querySelectorAll('[data-pressable-container="true"]').length,
      articles: document.querySelectorAll('article,[role="article"]').length,
      anchors: document.querySelectorAll("a").length,
      bodyLen: (document.body?.innerText || "").length,
      sample,
      buttons,
      htmlSample,
      collected
    };
  }
  function extractMetrics(container) {
    const isPureNum = (t) => /^[\d][\d.,]*[KkКкMmМм]?$/.test(t.trim());
    const deepNum = (el) => {
      if (!el) return 0;
      const own = (el.textContent || "").trim();
      if (isPureNum(own)) return parseCount(own);
      for (const c of el.querySelectorAll("*")) {
        const t = (c.textContent || "").trim();
        if (t && isPureNum(t)) return parseCount(t);
      }
      return 0;
    };
    const readCount = (b) => {
      let n = deepNum(b);
      if (!n) {
        let s = b.nextElementSibling;
        for (let i = 0; i < 2 && s && !n; i++) {
          n = deepNum(s);
          s = s.nextElementSibling;
        }
      }
      return n;
    };
    const RE_LIKE = /mi piace|\blike\b|нрав|me gusta|j.?aime|gefällt|gosto|curtir|beğen/i;
    const RE_REPLY = /rispondi|commenta|\brepl|comment|ответ|коммент|responder|répondre|antworten|comentar|yanıtla/i;
    const RE_REPOST = /ripubblica|repost|репост|reblog|reenviar|teilen/i;
    let likes = 0, replies = 0, reposts = 0;
    for (const b of container.querySelectorAll('[role="button"]')) {
      const svg = b.querySelector("svg");
      if (!svg) continue;
      const label = (svg.getAttribute("aria-label") || b.getAttribute("aria-label") || svg.querySelector("title")?.textContent || "").toLowerCase();
      if (!label) continue;
      if (RE_LIKE.test(label)) {
        const c = readCount(b);
        if (c) likes = c;
      } else if (RE_REPLY.test(label)) {
        const c = readCount(b);
        if (c) replies = c;
      } else if (RE_REPOST.test(label)) {
        const c = readCount(b);
        if (c) reposts = c;
      }
    }
    return { likes, replies, reposts };
  }
  function postedAtOf(container) {
    const dt = container.querySelector("time")?.getAttribute("datetime");
    return dt || void 0;
  }
  function collectSearchPosts(cur, max) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    let containers = [...document.querySelectorAll('[data-pressable-container="true"], article, [role="article"]')];
    if (!containers.length) {
      const anchors = [...document.querySelectorAll('a[href*="/post/"]')];
      containers = anchors.map((a) => {
        let c = a;
        for (let i = 0; i < 10 && c; i++) c = c.parentElement;
        return c;
      }).filter((c) => !!c);
    }
    for (const container of containers) {
      const link = container.querySelector('a[href*="/post/"]');
      if (!link) continue;
      const href = link.getAttribute("href") || "";
      const m = href.match(/\/post\/([A-Za-z0-9_-]+)/);
      if (!m) continue;
      const id = m[1];
      if (seen.has(id)) continue;
      seen.add(id);
      const author = (href.match(/\/@([\w.]+)/) || [])[1] || void 0;
      let text = (container.innerText || "").replace(/\s+/g, " ").trim();
      if (author) text = text.replace(new RegExp("^" + author.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), "").trim();
      text = text.replace(/^\d{1,2}[/.]\d{1,2}[/.]\d{2,4}\b/, "").trim();
      text = text.replace(/\b(Traduci|Translate|Перевести|Traducir|Übersetzen|Traduire)\b[\s\d.,KkМмMm]*$/i, "").trim();
      if (text.length < 10) continue;
      const { likes, replies, reposts } = extractMetrics(container);
      const postedAt = postedAtOf(container);
      out.push({ searchId: cur.searchId, query: cur.query, threadsPostId: id, author, text: text.slice(0, 1200), permalink: BASE + href.split("?")[0], likes, replies, reposts, postedAt });
      if (out.length >= max) break;
    }
    return out;
  }
  async function researchTick() {
    if (location.pathname.startsWith("/search")) {
      const st = await getResearch();
      if (!st || st.idx >= st.queue.length) return;
      const cur = st.queue[st.idx];
      await sleep(4e3);
      await scrollList(8);
      const posts = collectSearchPosts(cur, st.maxPerQuery);
      const diag = searchDiag(cur.query, posts.length);
      console.log(
        `%c[threadhunt] research \xAB${cur.query}\xBB \u2192 \u0441\u043E\u0431\u0440\u0430\u043D\u043E ${posts.length}`,
        "color:#6d5cf6;font-weight:bold",
        `
URL: ${diag.url}
\u0441\u0441\u044B\u043B\u043E\u043A-\u043D\u0430-\u043F\u043E\u0441\u0442: ${diag.postLinks} | @-\u043F\u043E\u0441\u0442: ${diag.userPostLinks} | pressable: ${diag.pressable} | article: ${diag.articles} | \u0432\u0441\u0435\u0433\u043E-\u0441\u0441\u044B\u043B\u043E\u043A: ${diag.anchors} | \u0442\u0435\u043A\u0441\u0442: ${diag.bodyLen}`
      );
      console.log("[threadhunt] \u043F\u0440\u0438\u043C\u0435\u0440\u044B \u0441\u0441\u044B\u043B\u043E\u043A:", diag.sample);
      console.log("[threadhunt] HTML-\u043E\u0431\u0440\u0430\u0437\u0435\u0446 (\u0441\u043A\u043E\u043F\u0438\u0440\u0443\u0439 \u0438 \u043F\u0440\u0438\u0448\u043B\u0438):\n", diag.htmlSample);
      chrome.runtime.sendMessage({ type: "research", posts, diag });
      st.collected = (st.collected || 0) + posts.length;
      st.idx++;
      if (st.idx < st.queue.length) {
        await chrome.storage.session.set({ [RESEARCH_KEY]: st });
        navigate(searchUrl(st.queue[st.idx].query));
      } else {
        const total = st.collected || 0;
        await chrome.storage.session.remove(RESEARCH_KEY);
        await chrome.storage.session.set({ [LAST_RESEARCH_KEY]: Date.now() });
        chrome.runtime.sendMessage({ type: "researchDone", total });
        console.log("[threadhunt] research \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D, \u0432\u0441\u0435\u0433\u043E \u0441\u043E\u0431\u0440\u0430\u043D\u043E", total);
      }
      return;
    }
    if (!location.pathname.startsWith("/messages")) return;
    const existing = await getResearch();
    if (existing) {
      if (existing.idx < existing.queue.length) navigate(searchUrl(existing.queue[existing.idx].query));
      return;
    }
    if (await getSweep()) return;
    const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
    const r = tasks?.research;
    if (!r?.enabled || !r.queries?.length) return;
    const runAtTs = r.runAt ? Date.parse(r.runAt) : 0;
    const { [LAST_RESEARCH_KEY]: last, lastResearchRunNow } = await chrome.storage.session.get([LAST_RESEARCH_KEY, "lastResearchRunNow"]);
    const isRunNow = !!runAtTs && runAtTs !== lastResearchRunNow;
    if (!isRunNow && last && Date.now() - last < Math.max(60, r.intervalMinutes || 720) * 6e4) return;
    if (isRunNow) await chrome.storage.session.set({ lastResearchRunNow: runAtTs });
    const state = { queue: r.queries.slice(0, 12), idx: 0, maxPerQuery: r.maxPerQuery || 15 };
    await chrome.storage.session.set({ [RESEARCH_KEY]: state });
    navigate(searchUrl(state.queue[0].query));
  }
  async function dmTestWatcher() {
    if (await getSweep()) return;
    const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
    if (tasks) await maybeStartDmTest(tasks);
  }
  var CSWEEP_KEY = "csweep";
  var LAST_CSWEEP_KEY = "lastCSweepAt";
  var REPLY_RX = /(reply|ответить|відповісти|rispondi|responder|répondre|antworten|yanıtla|cevapla|antwoorden|odpowiedz)/i;
  async function getCSweep() {
    const s = await chrome.storage.session.get(CSWEEP_KEY);
    return s[CSWEEP_KEY] || null;
  }
  async function setCSweep(v) {
    if (v) await chrome.storage.session.set({ [CSWEEP_KEY]: v });
    else await chrome.storage.session.remove(CSWEEP_KEY);
  }
  function findReplyButton(container) {
    const btns = [...container.querySelectorAll('[role="button"], button')].filter((b) => b.offsetParent !== null);
    for (const b of btns) {
      const label = (b.innerText || "") + " " + (b.getAttribute("aria-label") || "") + " " + (b.querySelector("svg")?.getAttribute("aria-label") || "");
      if (REPLY_RX.test(label) && !DECLINE_RX.test(label)) return b;
    }
    return null;
  }
  function captureComments() {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    const containers = [...document.querySelectorAll('[data-pressable-container="true"]')];
    for (let i = 1; i < containers.length; i++) {
      const c = containers[i];
      const link = c.querySelector('a[href*="/post/"]');
      const id = (link?.getAttribute("href")?.match(/\/post\/([A-Za-z0-9_-]+)/) || [])[1];
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const author = (c.querySelector('a[href^="/@"]')?.getAttribute("href") || "").replace(/^\/@/, "").split("/")[0];
      let text = "";
      for (const n of c.querySelectorAll('div[dir="auto"], span[dir="auto"]')) {
        const t = (n.innerText || "").replace(/\s+/g, " ").trim();
        if (t.length > text.length && t !== author) text = t;
      }
      out.push({ id, author, text, el: c });
    }
    return out;
  }
  var commentRunning = false;
  async function commentStep() {
    if (commentRunning) return;
    if (!/\/post\//.test(location.pathname)) return;
    const cs = await getCSweep();
    if (!cs) return;
    commentRunning = true;
    try {
      chrome.runtime.sendMessage({ type: "heartbeat", threadsLoggedIn: isLoggedIn() });
      const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
      runtimeCalib = tasks?.calibration ?? runtimeCalib;
      const stopTs = tasks?.limits?.stopAt ? Date.parse(tasks.limits.stopAt) : 0;
      if (stopTs && stopTs >= cs.startedAt) {
        serverLog("\u23F9 \u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E \u0432\u0440\u0443\u0447\u043D\u0443\u044E \u2014 \u043E\u0431\u0445\u043E\u0434 \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0435\u0432 \u043F\u0440\u0435\u0440\u0432\u0430\u043D", "warn");
        return finishCSweep(cs);
      }
      const rules = (tasks?.searches || []).filter((s) => s.commentRule?.enabled).map((s) => ({ searchId: s.searchId, keywords: s.keywords, mode: s.commentRule.mode, replyText: s.commentRule.replyText }));
      const alreadyReplied = new Set((tasks?.searches || []).flatMap((s) => s.alreadyReplied));
      if (!rules.length) return finishCSweep(cs);
      await sleep(3e3);
      await dismissWelcome();
      await scrollList(3);
      const comments = captureComments();
      for (const cm of comments) {
        if (cs.sent >= cs.repliesLeft) break;
        if (cs.attempted.includes(cm.id) || alreadyReplied.has(cm.id)) continue;
        let hit = null;
        for (const r of rules) {
          if (r.mode === "all") {
            hit = { searchId: r.searchId, replyText: r.replyText, keyword: "all" };
            break;
          }
          const m = matchKeyword(cm.text, r.keywords);
          if (m) {
            hit = { searchId: r.searchId, replyText: r.replyText, keyword: m };
            break;
          }
        }
        cs.scanned++;
        if (!hit || !hit.replyText.trim()) continue;
        cs.attempted.push(cm.id);
        await setCSweep(cs);
        if (cs.dryRun) {
          chrome.runtime.sendMessage({ type: "events", events: [{ searchId: hit.searchId, fromUserKey: cm.id, fromUsername: cm.author, matchedKeyword: hit.keyword, sent: false, section: "comment", message: cm.text, at: (/* @__PURE__ */ new Date()).toISOString() }] });
          continue;
        }
        const btn = findReplyButton(cm.el);
        let sent = false;
        if (btn) {
          btn.click();
          sent = await sendReply(hit.replyText);
        }
        if (sent) {
          cs.sent++;
          serverLog("\u{1F4AC} \u041E\u0442\u0432\u0435\u0442\u0438\u043B \u043D\u0430 \u043A\u043E\u043C\u043C\u0435\u043D\u0442 @" + (cm.author || "\u2014") + " \u043D\u0430 \xAB" + hit.keyword + "\xBB", "reply");
        } else serverLog("\u26A0\uFE0F \u041A\u043E\u043C\u043C\u0435\u043D\u0442 @" + (cm.author || "\u2014") + ": \u043D\u0435 \u043D\u0430\u0448\u0451\u043B \xAB\u041E\u0442\u0432\u0435\u0442\u0438\u0442\u044C\xBB/\u043F\u043E\u043B\u0435. \u041A\u043D\u043E\u043F\u043A\u0438: " + diagButtons(), "warn");
        chrome.runtime.sendMessage({ type: "events", events: [{ searchId: hit.searchId, fromUserKey: cm.id, fromUsername: cm.author, matchedKeyword: hit.keyword, sent, section: "comment", message: cm.text, at: (/* @__PURE__ */ new Date()).toISOString() }] });
        await sleep(cs.minDelayMs);
      }
      cs.postIdx++;
      if (cs.postIdx < cs.posts.length && cs.sent < cs.repliesLeft) {
        await setCSweep(cs);
        navigate(new URL(cs.posts[cs.postIdx]).pathname);
      } else {
        finishCSweep(cs);
      }
    } finally {
      commentRunning = false;
    }
  }
  async function finishCSweep(cs) {
    serverLog(`\u25A0 \u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0438: \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E ${cs.scanned}, \u043E\u0442\u0432\u0435\u0442\u043E\u0432 ${cs.sent}`);
    chrome.runtime.sendMessage({ type: "pass", report: { scanned: cs.scanned, sent: cs.sent, matched: cs.sent, sections: "comment", dryRun: !!cs.dryRun } });
    await chrome.storage.session.set({ [LAST_CSWEEP_KEY]: Date.now() });
    await setCSweep(null);
  }
  var CALIB_KEY = "calib";
  function detectBrowser() {
    const ua = navigator.userAgent;
    const brands = (navigator.userAgentData?.brands || []).map((x) => x.brand).join(" ");
    if (/YaBrowser/i.test(ua)) return "Yandex";
    if (/OPR|Opera/i.test(ua) || /Opera/i.test(brands)) return "Opera";
    if (/Edg/i.test(ua)) return "Edge";
    if (/Brave/i.test(brands) || navigator.brave) return "Brave";
    if (/Arc/i.test(ua)) return "Arc";
    if (/Chrome/i.test(ua)) return "Chrome";
    return "Chromium";
  }
  function uiLang() {
    return (document.documentElement.lang || navigator.language || "").slice(0, 12);
  }
  function captureControls() {
    return [...document.querySelectorAll('[role="button"], button')].filter((b) => b.offsetParent !== null).map((b) => ({
      text: (b.innerText || "").trim().slice(0, 40),
      aria: (b.getAttribute("aria-label") || b.querySelector("svg")?.getAttribute("aria-label") || "").slice(0, 40),
      role: b.getAttribute("role") || b.tagName.toLowerCase(),
      filled: isFilled(b)
    })).filter((c) => c.text && c.text.length < 30 || c.aria).slice(0, 40);
  }
  async function getCalib() {
    const s = await chrome.storage.session.get(CALIB_KEY);
    return s[CALIB_KEY] || null;
  }
  async function setCalib(v) {
    if (v) await chrome.storage.session.set({ [CALIB_KEY]: v });
    else await chrome.storage.session.remove(CALIB_KEY);
  }
  function sendCalibration() {
    chrome.runtime.sendMessage({ type: "calibrate", browser: detectBrowser(), lang: uiLang(), controls: captureControls() });
  }
  async function calibrationStep() {
    if (!location.pathname.startsWith("/messages")) return;
    const calib = await getCalib();
    if (!calib) return;
    if (await getSweep()) return;
    if (calib.phase === "list") {
      await sleep(3e3);
      await dismissWelcome();
      await scrollList(1);
      const chats = collectChats("requests");
      if (!chats.length) {
        serverLog("\u{1F3AF} \u041A\u0430\u043B\u0438\u0431\u0440\u043E\u0432\u043A\u0430: \u043D\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u0445 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u2014 \u0441\u043D\u0438\u043C\u0430\u044E \u0441 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u044D\u043A\u0440\u0430\u043D\u0430", "info");
        sendCalibration();
        await setCalib(null);
        return;
      }
      await setCalib({ phase: "capture" });
      navigate(chats[0].href);
      return;
    }
    if (calib.phase === "capture") {
      await sleep(3500);
      sendCalibration();
      serverLog("\u{1F3AF} \u041A\u0430\u043B\u0438\u0431\u0440\u043E\u0432\u043A\u0430: \u0441\u043D\u044F\u043B \u043A\u043D\u043E\u043F\u043A\u0438 \u044D\u043A\u0440\u0430\u043D\u0430 \u0437\u0430\u043F\u0440\u043E\u0441\u0430, \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043B \u043D\u0430 \u0418\u0418", "info");
      await setCalib(null);
      return;
    }
  }
  void step();
  setInterval(() => void step(), 3e4);
  void researchTick();
  setInterval(() => void researchTick(), 6e4);
  void dmTestWatcher();
  setInterval(() => void dmTestWatcher(), 2e4);
  void calibrationStep();
  setInterval(() => void calibrationStep(), 15e3);
  void commentStep();
  setInterval(() => void commentStep(), 2e4);
})();
