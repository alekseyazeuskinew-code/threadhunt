"use strict";
(() => {
  // ../shared/src/keywords.ts
  function normalize(text) {
    return (text || "").toLowerCase().replace(/ё/g, "\u0435");
  }
  function matchKeyword(text, keywords) {
    const norm = normalize(text);
    for (const kw of keywords) {
      const needle = normalize(kw.text);
      if (!needle) continue;
      const mode = kw.mode ?? "root";
      if (mode === "root" && norm.includes(needle)) return kw.text;
      if (mode === "exact" && norm.trim() === needle.trim()) return kw.text;
      if (mode === "word") {
        const esc = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const re = new RegExp(`(^|[^a-z\u0430-\u044F0-9_])${esc}([^a-z\u0430-\u044F0-9_]|$)`, "i");
        if (re.test(norm)) return kw.text;
      }
    }
    return null;
  }

  // src/content.ts
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var BASE = location.origin;
  var SECTIONS = [
    { url: "/messages/requests", label: "requests" },
    { url: "/messages/hidden", label: "hidden" },
    { url: "/messages/", label: "main" }
  ];
  function withinWorkingHours(wh) {
    if (!wh.enabled) return true;
    const d = /* @__PURE__ */ new Date();
    const cur = d.getHours() * 60 + d.getMinutes();
    const [fh, fm] = wh.from.split(":").map(Number);
    const [th, tm] = wh.to.split(":").map(Number);
    const from = fh * 60 + fm;
    const to = th * 60 + tm;
    return from <= to ? cur >= from && cur <= to : cur >= from || cur <= to;
  }
  var SWEEP_KEY = "sweep";
  var LAST_SWEEP_KEY = "lastSweepAt";
  var TEST_RESULT_KEY = "th_test_result";
  var COOLDOWN_MS = 6e4;
  async function getSweep() {
    const s = await chrome.storage.session.get(SWEEP_KEY);
    return s[SWEEP_KEY] || null;
  }
  async function setSweep(sw) {
    if (sw) await chrome.storage.session.set({ [SWEEP_KEY]: sw });
    else await chrome.storage.session.remove(SWEEP_KEY);
  }
  function isLoggedIn() {
    return !!document.querySelector('a[href^="/messages"]') || location.pathname.startsWith("/messages");
  }
  async function scrollList(times = 3) {
    for (let i = 0; i < times; i++) {
      const cands = [...document.querySelectorAll("div")].filter((d) => {
        const cs = getComputedStyle(d);
        return /auto|scroll/.test(cs.overflowY) && d.scrollHeight > d.clientHeight + 50;
      });
      for (const c of cands) c.scrollTop = c.scrollHeight;
      await sleep(900);
    }
  }
  function collectChats(section) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const a of document.querySelectorAll('a[href^="/messages/t/"]')) {
      const href = a.getAttribute("href") || "";
      const id = (href.match(/\/t\/(\d+)/) || [])[1];
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const name = (a.innerText || "").split("\n")[0].trim();
      out.push({ id, href, name, section });
    }
    return out;
  }
  function readLastMessage(forceIncoming = false) {
    const input = document.querySelector('[contenteditable="true"][role="textbox"]');
    let col = input;
    for (let i = 0; i < 6 && col; i++) col = col.parentElement;
    const colRect = col ? col.getBoundingClientRect() : { x: 0, width: window.innerWidth };
    const inputTop = input ? input.getBoundingClientRect().top : Infinity;
    const nodes = [...document.querySelectorAll('div[dir="auto"], span[dir="auto"]')].filter(
      (e) => e.innerText && e.innerText.trim().length > 1
    );
    const msgs = [];
    const seen = /* @__PURE__ */ new Set();
    for (const b of nodes) {
      const t = b.innerText.trim().replace(/\s+/g, " ");
      if (/^\w{3,9} \d{1,2}, \d{4}/.test(t)) continue;
      if (t === "Message unavailable") continue;
      if (t.length < 24 && (ACCEPT_RX.test(t) || DECLINE_RX.test(t))) continue;
      const r = b.getBoundingClientRect();
      if (r.bottom > inputTop + 5) continue;
      const leftGap = r.x - colRect.x;
      const rightGap = colRect.x + colRect.width - (r.x + r.width);
      if (leftGap < -20) continue;
      if (Math.min(leftGap, rightGap) >= 150) continue;
      const key = t.slice(0, 60);
      if (seen.has(key)) continue;
      seen.add(key);
      msgs.push({ text: t, incoming: forceIncoming ? true : leftGap < rightGap });
    }
    return msgs.length ? msgs[msgs.length - 1] : null;
  }
  var ACCEPT_RX = /(accept|accetta|aceptar|aceitar|accepter|akzeptier|allow|consenti|permett|permitir|autoriser|zulassen|unhide|mostra|unblock|onayla|kabul|akcept|прийн|дозвол|принять|разреш|показать|разблок|қабыл|рұқсат|рұқсат бер)/i;
  var DECLINE_RX = /(decline|delete|reject|block|remove|rifiuta|elimina|rechazar|recusar|refuser|ablehnen|löschen|supprimer|eliminar|engelle|reddet|sil|відхил|видалити|заблок|отклон|удалить|удали|жою|бас тарт)/i;
  function isFilled(el) {
    const bg = getComputedStyle(el).backgroundColor;
    return !!bg && bg !== "transparent" && bg !== "rgba(0, 0, 0, 0)";
  }
  async function acceptRequestIfNeeded() {
    const buttons = [...document.querySelectorAll('[role="button"], button')].filter((b) => {
      const t = (b.innerText || "").trim();
      return b.offsetParent !== null && t.length > 0 && t.length < 24;
    });
    let target = buttons.find((b) => ACCEPT_RX.test(b.innerText) && !DECLINE_RX.test(b.innerText));
    if (!target) {
      target = buttons.find((b) => !DECLINE_RX.test(b.innerText) && isFilled(b));
    }
    if (target) {
      target.click();
      await sleep(1500);
    }
  }
  async function sendReply(text) {
    try {
      const inputs = document.querySelectorAll('[contenteditable="true"][role="textbox"]');
      const input = inputs[inputs.length - 1];
      if (!input) return false;
      input.focus();
      document.execCommand("insertText", false, text);
      await sleep(500);
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      await sleep(1500);
      return true;
    } catch {
      return false;
    }
  }
  function navigate(path) {
    location.assign(BASE + path);
  }
  async function step() {
    if (!location.pathname.startsWith("/messages")) return;
    chrome.runtime.sendMessage({ type: "heartbeat", threadsLoggedIn: isLoggedIn() });
    let sweep = await getSweep();
    if (!sweep) {
      const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
      if (!tasks?.active || !tasks.searches.length) return;
      const lim = tasks.limits;
      if (lim && !withinWorkingHours(lim.workingHours)) return;
      if (lim && lim.repliesRemainingToday <= 0) return;
      const { [LAST_SWEEP_KEY]: last } = await chrome.storage.session.get(LAST_SWEEP_KEY);
      if (last && Date.now() - last < COOLDOWN_MS) return;
      sweep = {
        phase: "collect",
        sectionIdx: 0,
        seenIds: [],
        chats: [],
        processIdx: 0,
        events: [],
        keywords: tasks.searches.flatMap((s) => s.keywords.map((k) => ({ ...k, searchId: s.searchId }))),
        replyBySearch: Object.fromEntries(tasks.searches.map((s) => [s.searchId, s.replyTemplates[0]])),
        repliedKeys: tasks.searches.flatMap((s) => s.alreadyReplied),
        minDelayMs: lim?.minDelayMs ?? 8e3,
        maxDialogs: lim?.maxDialogs ?? 40,
        repliesLeft: lim?.repliesRemainingToday ?? 40,
        sent: 0,
        expectPath: SECTIONS[0].url,
        guard: 0
      };
      await setSweep(sweep);
      navigate(SECTIONS[0].url);
      return;
    }
    if (!location.pathname.startsWith(sweep.expectPath.replace(/\/$/, "")) && sweep.guard < 3) {
      sweep.guard++;
      await setSweep(sweep);
      navigate(sweep.expectPath);
      return;
    }
    if (sweep.phase === "collect") {
      const sec = SECTIONS[sweep.sectionIdx];
      await sleep(3500);
      await scrollList();
      const seen = new Set(sweep.seenIds);
      const repliedKeys = new Set(sweep.repliedKeys);
      for (const c of collectChats(sec.label)) {
        if (sweep.chats.length >= sweep.maxDialogs) break;
        if (seen.has(c.id) || repliedKeys.has(c.id)) continue;
        seen.add(c.id);
        sweep.chats.push(c);
      }
      sweep.seenIds = [...seen];
      sweep.sectionIdx++;
      if (sweep.sectionIdx < SECTIONS.length) {
        sweep.expectPath = SECTIONS[sweep.sectionIdx].url;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.expectPath);
      } else {
        if (!sweep.chats.length) return finishSweep(sweep);
        sweep.phase = "process";
        sweep.processIdx = 0;
        sweep.expectPath = sweep.chats[0].href;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.chats[0].href);
      }
      return;
    }
    if (sweep.phase === "process") {
      const chat = sweep.chats[sweep.processIdx];
      await sleep(2500);
      sweep.scanned = (sweep.scanned || 0) + 1;
      const last = readLastMessage(chat.section !== "main");
      if (last && last.incoming) {
        const matched = matchKeyword(last.text, sweep.keywords);
        if (matched) {
          const kw = sweep.keywords.find((k) => k.text === matched);
          const tpl = sweep.replyBySearch[kw.searchId];
          if (tpl) {
            let sent = false;
            if (!sweep.dryRun) {
              if (chat.section !== "main") await acceptRequestIfNeeded();
              sent = await sendReply(tpl.text);
              if (sent) sweep.sent++;
            }
            sweep.events.push({
              searchId: kw.searchId,
              fromUserKey: chat.id,
              fromUsername: chat.name,
              matchedKeyword: matched,
              templateId: tpl.id,
              sent,
              section: chat.section,
              at: (/* @__PURE__ */ new Date()).toISOString()
            });
            if (!sweep.dryRun) {
              await sleep(sweep.minDelayMs);
              if (sweep.sent >= sweep.repliesLeft) return finishSweep(sweep);
            }
          }
        }
      }
      sweep.processIdx++;
      if (sweep.processIdx < sweep.chats.length) {
        sweep.expectPath = sweep.chats[sweep.processIdx].href;
        sweep.guard = 0;
        await setSweep(sweep);
        navigate(sweep.chats[sweep.processIdx].href);
      } else {
        finishSweep(sweep);
      }
      return;
    }
  }
  async function finishSweep(sweep) {
    if (sweep.dryRun) {
      await chrome.storage.local.set({
        [TEST_RESULT_KEY]: { scanned: sweep.scanned || 0, matched: sweep.events.length, at: (/* @__PURE__ */ new Date()).toISOString(), done: true }
      });
    } else {
      if (sweep.events.length) chrome.runtime.sendMessage({ type: "events", events: sweep.events });
    }
    await chrome.storage.session.set({ [LAST_SWEEP_KEY]: Date.now() });
    await setSweep(null);
  }
  async function startTestSweep() {
    if (!location.pathname.startsWith("/messages")) return { ok: false, reason: "not_messages" };
    if (await getSweep()) return { ok: false, reason: "busy" };
    const tasks = await chrome.runtime.sendMessage({ type: "getTasks" });
    const searches = tasks?.searches || [];
    const keywords = searches.flatMap((s) => s.keywords.map((k) => ({ ...k, searchId: s.searchId })));
    if (!keywords.length) return { ok: false, reason: "no_keywords" };
    await chrome.storage.local.set({ [TEST_RESULT_KEY]: { scanned: 0, matched: 0, at: (/* @__PURE__ */ new Date()).toISOString(), done: false } });
    const sweep = {
      phase: "collect",
      sectionIdx: 0,
      seenIds: [],
      chats: [],
      processIdx: 0,
      events: [],
      keywords,
      replyBySearch: Object.fromEntries(searches.map((s) => [s.searchId, s.replyTemplates[0]])),
      repliedKeys: [],
      // в тесте смотрим всех, даже тех, кому уже отвечали
      minDelayMs: 0,
      maxDialogs: tasks?.limits?.maxDialogs ?? 40,
      repliesLeft: 0,
      sent: 0,
      expectPath: SECTIONS[0].url,
      guard: 0,
      dryRun: true,
      scanned: 0
    };
    await setSweep(sweep);
    navigate(SECTIONS[0].url);
    return { ok: true };
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "startTest") {
      startTestSweep().then(sendResponse);
      return true;
    }
  });
  void step();
  setInterval(() => void step(), 3e4);
})();
